PRAGMA defer_foreign_keys=TRUE;
CREATE TABLE d1_migrations(
		id         INTEGER PRIMARY KEY AUTOINCREMENT,
		name       TEXT UNIQUE,
		applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
);
INSERT INTO "d1_migrations" VALUES(1,'0001_initial_schema.sql','2025-11-17 06:09:01');
INSERT INTO "d1_migrations" VALUES(2,'0002_artist_achievement.sql','2025-11-17 06:09:02');
INSERT INTO "d1_migrations" VALUES(3,'0003_complete_valuation_system.sql','2025-11-17 06:09:02');
INSERT INTO "d1_migrations" VALUES(4,'0004_admin_users.sql','2025-11-17 06:09:02');
INSERT INTO "d1_migrations" VALUES(5,'0005_notifications.sql','2025-11-17 06:09:02');
INSERT INTO "d1_migrations" VALUES(6,'0006_paper_based_valuation.sql','2025-11-17 06:09:03');
INSERT INTO "d1_migrations" VALUES(7,'0007_complete_user_system.sql','2025-11-17 06:09:03');
INSERT INTO "d1_migrations" VALUES(8,'0008_expert_application_system.sql','2025-11-17 06:09:03');
INSERT INTO "d1_migrations" VALUES(9,'0009_enhanced_features.sql','2025-11-17 06:09:03');
INSERT INTO "d1_migrations" VALUES(10,'0010_add_engagement_columns.sql','2025-11-17 06:09:04');
INSERT INTO "d1_migrations" VALUES(11,'0011_add_purchase_auction_system.sql','2025-11-17 06:09:04');
INSERT INTO "d1_migrations" VALUES(12,'0012_add_museum_gallery_and_rewards.sql','2025-11-17 06:09:04');
INSERT INTO "d1_migrations" VALUES(13,'0013_add_artist_rank_framework.sql','2025-11-17 06:09:05');
INSERT INTO "d1_migrations" VALUES(14,'0014_password_reset_tokens.sql','2025-11-17 06:09:05');
INSERT INTO "d1_migrations" VALUES(15,'0015_add_google_id.sql','2025-11-17 06:09:05');
INSERT INTO "d1_migrations" VALUES(16,'0015a_trading_tables.sql','2025-11-17 06:09:05');
INSERT INTO "d1_migrations" VALUES(17,'0015b_trading_triggers.sql','2025-11-17 06:09:06');
INSERT INTO "d1_migrations" VALUES(18,'0018_opensea_ownership_transactions.sql','2025-11-17 06:09:06');
INSERT INTO "d1_migrations" VALUES(19,'0019_bundle_collection_traits_lazy.sql','2025-11-17 06:09:06');
INSERT INTO "d1_migrations" VALUES(20,'0020_sweep_portfolio_multichain.sql','2025-11-17 06:09:06');
INSERT INTO "d1_migrations" VALUES(21,'0021_ai_authenticity_verification.sql','2025-11-17 06:09:07');
INSERT INTO "d1_migrations" VALUES(22,'0022_advanced_royalty_automation.sql','2025-11-17 06:09:07');
INSERT INTO "d1_migrations" VALUES(23,'0023_museum_partnership_platform.sql','2025-11-17 06:09:07');
INSERT INTO "d1_migrations" VALUES(24,'0024_expand_partnership_categories.sql','2025-11-17 07:12:23');
CREATE TABLE artists (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT UNIQUE,
  bio TEXT,
  career_years INTEGER DEFAULT 0,
  education TEXT,
  exhibitions_count INTEGER DEFAULT 0,
  awards_count INTEGER DEFAULT 0,
  profile_image TEXT,
  wallet_address TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
, solo_exhibitions_count INTEGER DEFAULT 0, group_exhibitions_count INTEGER DEFAULT 0, competition_awards_count INTEGER DEFAULT 0, achievement_score REAL DEFAULT 0, latest_exhibition_year INTEGER DEFAULT 2024, latest_award_year INTEGER DEFAULT 2024, total_exhibitions INTEGER DEFAULT 0, solo_exhibitions INTEGER DEFAULT 0, group_exhibitions INTEGER DEFAULT 0, total_awards INTEGER DEFAULT 0, artist_achievement_score REAL DEFAULT 0);
CREATE TABLE artworks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  artist_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  category TEXT NOT NULL, 
  technique TEXT, 
  size_width REAL, 
  size_height REAL, 
  size_depth REAL, 
  creation_year INTEGER,
  image_url TEXT NOT NULL,
  thumbnail_url TEXT,
  
  
  base_material_cost REAL DEFAULT 0, 
  labor_hours REAL DEFAULT 0, 
  market_demand_score INTEGER DEFAULT 0, 
  rarity_score INTEGER DEFAULT 0, 
  
  
  artistic_quality_score INTEGER DEFAULT 0, 
  originality_score INTEGER DEFAULT 0, 
  cultural_significance_score INTEGER DEFAULT 0, 
  technical_excellence_score INTEGER DEFAULT 0, 
  
  
  estimated_value REAL DEFAULT 0, 
  min_price REAL DEFAULT 0, 
  current_price REAL DEFAULT 0, 
  
  
  is_minted BOOLEAN DEFAULT 0,
  nft_token_id TEXT,
  nft_contract_address TEXT,
  blockchain_network TEXT, 
  ipfs_hash TEXT,
  
  status TEXT DEFAULT 'draft', 
  views_count INTEGER DEFAULT 0,
  likes_count INTEGER DEFAULT 0,
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP, artist_achievement_score INTEGER DEFAULT 0, content_depth_score INTEGER DEFAULT 0, expression_score INTEGER DEFAULT 0, originality_innovation_score INTEGER DEFAULT 0, collection_value_score INTEGER DEFAULT 0, blockchain_hash TEXT, copyright_registration_number TEXT, license_type TEXT DEFAULT 'exclusive', license_scope TEXT, certification_score INTEGER DEFAULT 0, youtube_views INTEGER DEFAULT 0, instagram_engagement INTEGER DEFAULT 0, platform_likes INTEGER DEFAULT 0, platform_comments INTEGER DEFAULT 0, platform_shares INTEGER DEFAULT 0, google_trends_score INTEGER DEFAULT 0, media_coverage_count INTEGER DEFAULT 0, popularity_score INTEGER DEFAULT 0, artist_achievement_final_score INTEGER DEFAULT 0, artwork_content_final_score INTEGER DEFAULT 0, certification_final_score INTEGER DEFAULT 0, expert_evaluation_final_score INTEGER DEFAULT 0, popularity_final_score INTEGER DEFAULT 0, weight_artist REAL DEFAULT 0.25, weight_artwork REAL DEFAULT 0.30, weight_certification REAL DEFAULT 0.15, weight_expert REAL DEFAULT 0.20, weight_popularity REAL DEFAULT 0.10, final_value_score REAL DEFAULT 0, average_rating REAL DEFAULT 0, reviews_count INTEGER DEFAULT 0, is_listed BOOLEAN DEFAULT 0, current_price_eth REAL, last_sale_price_eth REAL, last_sale_date DATETIME, total_sales INTEGER DEFAULT 0, total_volume_eth REAL DEFAULT 0.0, collection_id INTEGER, collection_slug TEXT, lazy_mint BOOLEAN DEFAULT 0, first_buyer_id INTEGER, minted_at DATETIME, minting_transaction_hash TEXT, chain_id INTEGER DEFAULT 1, chain_name TEXT DEFAULT 'Ethereum',
  
  FOREIGN KEY (artist_id) REFERENCES artists(id)
);
CREATE TABLE valuation_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  artwork_id INTEGER NOT NULL,
  evaluator_name TEXT,
  evaluator_role TEXT, 
  
  
  artistic_quality INTEGER,
  originality INTEGER,
  cultural_significance INTEGER,
  technical_excellence INTEGER,
  market_potential INTEGER,
  
  estimated_value REAL,
  evaluation_notes TEXT,
  evaluated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (artwork_id) REFERENCES artworks(id)
);
CREATE TABLE transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  artwork_id INTEGER NOT NULL,
  transaction_type TEXT NOT NULL, 
  from_address TEXT,
  to_address TEXT,
  price REAL,
  currency TEXT DEFAULT 'ETH',
  transaction_hash TEXT,
  blockchain_network TEXT,
  gas_fee REAL,
  status TEXT DEFAULT 'pending', 
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP, buyer_id INTEGER, seller_id INTEGER, payment_method TEXT DEFAULT 'metamask', completed_at DATETIME,
  
  FOREIGN KEY (artwork_id) REFERENCES artworks(id)
);
CREATE TABLE collections (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  description TEXT,
  curator_name TEXT,
  cover_image TEXT,
  artwork_count INTEGER DEFAULT 0,
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE collection_artworks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  collection_id INTEGER NOT NULL,
  artwork_id INTEGER NOT NULL,
  display_order INTEGER DEFAULT 0,
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (collection_id) REFERENCES collections(id),
  FOREIGN KEY (artwork_id) REFERENCES artworks(id)
);
CREATE TABLE likes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  artwork_id INTEGER NOT NULL,
  user_address TEXT NOT NULL,
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (artwork_id) REFERENCES artworks(id),
  UNIQUE(artwork_id, user_address)
);
CREATE TABLE expert_evaluations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  artwork_id INTEGER NOT NULL,
  expert_name TEXT NOT NULL,
  expert_level TEXT NOT NULL, 
  expert_institution TEXT,
  
  
  technique_mastery_score INTEGER DEFAULT 0, 
  art_historical_significance_score INTEGER DEFAULT 0, 
  marketability_score INTEGER DEFAULT 0, 
  development_potential_score INTEGER DEFAULT 0, 
  
  overall_score INTEGER DEFAULT 0,
  evaluation_comment TEXT,
  evaluated_at DATETIME DEFAULT CURRENT_TIMESTAMP, reward_eth REAL DEFAULT 0.0, reward_status TEXT DEFAULT 'pending', reward_tx_hash TEXT, reward_paid_at DATETIME,
  
  FOREIGN KEY (artwork_id) REFERENCES artworks(id)
);
CREATE TABLE admin_users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  full_name TEXT,
  role TEXT DEFAULT 'admin', 
  is_active BOOLEAN DEFAULT 1,
  last_login_at DATETIME,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
INSERT INTO "admin_users" VALUES(1,'admin','240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9','admin@gallerypia.com','시스템 관리자','super_admin',1,'2025-11-17 07:02:35','2025-11-17 06:09:02','2025-11-17 06:09:02');
CREATE TABLE admin_sessions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  session_token TEXT UNIQUE NOT NULL,
  admin_user_id INTEGER NOT NULL,
  ip_address TEXT,
  user_agent TEXT,
  expires_at DATETIME NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (admin_user_id) REFERENCES admin_users(id)
);
INSERT INTO "admin_sessions" VALUES(1,'3567b074-937b-459e-9650-0696a4a9de48',1,NULL,NULL,'2025-11-18T07:02:35.554Z','2025-11-17 07:02:35');
CREATE TABLE admin_activity_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  admin_user_id INTEGER NOT NULL,
  action TEXT NOT NULL, 
  entity_type TEXT, 
  entity_id INTEGER,
  details TEXT, 
  ip_address TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (admin_user_id) REFERENCES admin_users(id)
);
INSERT INTO "admin_activity_logs" VALUES(1,1,'login',NULL,NULL,'{"username":"admin"}',NULL,'2025-11-17 07:02:35');
CREATE TABLE notifications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  type TEXT NOT NULL, 
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  related_entity_type TEXT, 
  related_entity_id INTEGER,
  is_read BOOLEAN DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE artist_exhibitions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  artist_id INTEGER NOT NULL,
  exhibition_type TEXT NOT NULL, 
  exhibition_name TEXT NOT NULL,
  venue_name TEXT, 
  authority_level INTEGER DEFAULT 3, 
  start_date DATE,
  end_date DATE,
  exhibition_year INTEGER,
  recency_coefficient REAL DEFAULT 1.0, 
  exhibition_score INTEGER DEFAULT 0, 
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (artist_id) REFERENCES artists(id)
);
CREATE TABLE artist_awards (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  artist_id INTEGER NOT NULL,
  award_name TEXT NOT NULL,
  competition_name TEXT,
  award_rank TEXT, 
  authority_level INTEGER DEFAULT 3, 
  award_year INTEGER,
  recency_coefficient REAL DEFAULT 1.0,
  award_score INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (artist_id) REFERENCES artists(id)
);
CREATE TABLE artwork_content_evaluation (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  artwork_id INTEGER NOT NULL UNIQUE,
  
  
  content_depth_score INTEGER DEFAULT 0, 
  content_comment TEXT,
  
  
  expression_score INTEGER DEFAULT 0, 
  expression_comment TEXT,
  
  
  originality_score INTEGER DEFAULT 0, 
  originality_comment TEXT,
  
  
  collection_value_score INTEGER DEFAULT 0, 
  collection_value_comment TEXT,
  
  
  artwork_content_final_score INTEGER DEFAULT 0,
  
  evaluated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (artwork_id) REFERENCES artworks(id) ON DELETE CASCADE
);
CREATE TABLE artwork_certification (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  artwork_id INTEGER NOT NULL UNIQUE,
  
  
  blockchain_hash TEXT, 
  blockchain_network TEXT, 
  transaction_hash TEXT, 
  
  
  copyright_registered BOOLEAN DEFAULT FALSE,
  copyright_registration_number TEXT, 
  copyright_registration_date DATE,
  
  
  license_type TEXT DEFAULT 'exclusive', 
  license_scope TEXT, 
  license_details TEXT,
  
  
  ownership_transfer_count INTEGER DEFAULT 0,
  
  
  certification_score REAL DEFAULT 0,
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (artwork_id) REFERENCES artworks(id) ON DELETE CASCADE
);
CREATE TABLE artwork_popularity (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  artwork_id INTEGER NOT NULL UNIQUE,
  
  
  youtube_views INTEGER DEFAULT 0,
  youtube_likes INTEGER DEFAULT 0,
  instagram_likes INTEGER DEFAULT 0,
  instagram_comments INTEGER DEFAULT 0,
  instagram_shares INTEGER DEFAULT 0,
  instagram_engagement INTEGER DEFAULT 0, 
  
  
  platform_likes INTEGER DEFAULT 0,
  platform_comments INTEGER DEFAULT 0,
  platform_shares INTEGER DEFAULT 0,
  platform_views INTEGER DEFAULT 0,
  
  
  google_trends_score INTEGER DEFAULT 0, 
  
  
  media_coverage_count INTEGER DEFAULT 0, 
  major_media_count INTEGER DEFAULT 0, 
  
  
  popularity_final_score REAL DEFAULT 0,
  
  last_updated DATETIME DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (artwork_id) REFERENCES artworks(id) ON DELETE CASCADE
);
CREATE TABLE artwork_final_valuation (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  artwork_id INTEGER NOT NULL UNIQUE,
  
  
  module1_artist_achievement REAL DEFAULT 0, 
  module2_artwork_content REAL DEFAULT 0, 
  module3_certification REAL DEFAULT 0, 
  module4_expert_evaluation REAL DEFAULT 0, 
  module5_popularity REAL DEFAULT 0, 
  
  
  weight_alpha1 REAL DEFAULT 0.25, 
  weight_alpha2 REAL DEFAULT 0.30, 
  weight_alpha3 REAL DEFAULT 0.20, 
  weight_alpha4 REAL DEFAULT 0.15, 
  weight_alpha5 REAL DEFAULT 0.10, 
  
  
  final_value_score REAL DEFAULT 0,
  
  
  recommended_price_min INTEGER DEFAULT 0,
  recommended_price_max INTEGER DEFAULT 0,
  recommended_price_avg INTEGER DEFAULT 0,
  
  
  art_value_index REAL DEFAULT 0, 
  
  
  market_transparency_index REAL DEFAULT 0, 
  
  calculated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (artwork_id) REFERENCES artworks(id) ON DELETE CASCADE
);
CREATE TABLE users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT, 
  username TEXT UNIQUE NOT NULL,
  full_name TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'buyer', 
  profile_image TEXT,
  bio TEXT,
  phone TEXT,
  website TEXT,
  is_verified INTEGER DEFAULT 0,
  is_active INTEGER DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  last_login_at DATETIME
, organization_name TEXT, organization_type TEXT, organization_description TEXT, organization_address TEXT, organization_website TEXT, organization_contact_email TEXT, organization_phone TEXT, curator_count INTEGER DEFAULT 0, exhibition_count INTEGER DEFAULT 0, evaluator_rank TEXT, evaluator_status TEXT DEFAULT 'inactive', evaluator_qualification TEXT, evaluator_approved_at DATETIME, wallet_address TEXT, google_id TEXT, total_sales_count INTEGER DEFAULT 0, total_purchases_count INTEGER DEFAULT 0, total_sales_volume_eth REAL DEFAULT 0.0, total_purchases_volume_eth REAL DEFAULT 0.0, total_earned_royalties_eth REAL DEFAULT 0.0);
INSERT INTO "users" VALUES(1,'moma@example.com','ef92b778bafe771e89245b89ecbc08a44a4e166c06659911881f383d4473e94f','moma_museum','Museum of Modern Art','museum',NULL,NULL,NULL,NULL,0,1,'2025-11-17 06:09:04','2025-11-17 06:09:04',NULL,'Museum of Modern Art','museum','Leading museum of modern and contemporary art',NULL,NULL,NULL,NULL,0,0,NULL,'inactive',NULL,NULL,NULL,NULL,0,0,0,0,0);
INSERT INTO "users" VALUES(2,'pace@example.com','8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92','pace_gallery','Pace Gallery','gallery',NULL,NULL,NULL,NULL,0,1,'2025-11-17 06:09:04','2025-11-17 06:09:04',NULL,'Pace Gallery','gallery','Contemporary art gallery representing world-renowned artists',NULL,NULL,NULL,NULL,0,0,NULL,'inactive',NULL,NULL,NULL,NULL,0,0,0,0,0);
INSERT INTO "users" VALUES(3,'parkminsu@artist.com',NULL,'parkminsu','박민수','artist',NULL,NULL,NULL,NULL,0,1,'2025-11-17 07:24:06','2025-11-17 07:24:06',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,'inactive',NULL,NULL,'0x1234567890abcdef1234567890abcdef12345678',NULL,0,0,0,0,0);
INSERT INTO "users" VALUES(4,'buyer@demo.com','demo1234','buyer_demo','구매자 데모','buyer',NULL,NULL,NULL,NULL,1,1,'2025-11-23 02:54:55','2025-11-23 02:54:55',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,'inactive',NULL,NULL,NULL,NULL,0,0,0,0,0);
INSERT INTO "users" VALUES(5,'seller@demo.com','demo1234','seller_demo','판매자 데모','seller',NULL,NULL,NULL,NULL,1,1,'2025-11-23 02:54:55','2025-11-23 02:54:55',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,'inactive',NULL,NULL,NULL,NULL,0,0,0,0,0);
INSERT INTO "users" VALUES(6,'artist@demo.com','demo1234','artist_demo','작가 데모','artist',NULL,'데모 작가입니다.',NULL,NULL,1,1,'2025-11-23 02:54:55','2025-11-23 02:54:55',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,'inactive',NULL,NULL,NULL,NULL,0,0,0,0,0);
INSERT INTO "users" VALUES(7,'expert@demo.com','demo1234','expert_demo','전문가 데모','expert',NULL,NULL,NULL,NULL,1,1,'2025-11-23 02:54:55','2025-11-23 02:54:55',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,'senior','active',NULL,NULL,NULL,NULL,0,0,0,0,0);
INSERT INTO "users" VALUES(8,'museum@demo.com','demo1234','museum_demo','미술관 담당자','museum',NULL,NULL,NULL,NULL,1,1,'2025-11-23 02:54:55','2025-11-23 02:54:55',NULL,'데모 미술관','public',NULL,NULL,NULL,NULL,NULL,0,0,NULL,'inactive',NULL,NULL,NULL,NULL,0,0,0,0,0);
INSERT INTO "users" VALUES(9,'gallery@demo.com','demo1234','gallery_demo','갤러리 담당자','gallery',NULL,NULL,NULL,NULL,1,1,'2025-11-23 02:54:55','2025-11-23 02:54:55',NULL,'데모 갤러리','commercial',NULL,NULL,NULL,NULL,NULL,0,0,NULL,'inactive',NULL,NULL,NULL,NULL,0,0,0,0,0);
INSERT INTO "users" VALUES(10,'admin@demo.com','admin1234','admin_demo','관리자 데모','admin',NULL,NULL,NULL,NULL,1,1,'2025-11-23 02:59:15','2025-11-23 02:59:15',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,'inactive',NULL,NULL,NULL,NULL,0,0,0,0,0);
INSERT INTO "users" VALUES(11,'test@gallerypia.com','Test1234!@#$','gallerypia_tester','갤러리피아 테스터','collector',NULL,'NFT 아트 수집가입니다','010-1234-5678',NULL,0,1,'2025-11-24 00:41:16','2025-11-24 00:41:16','2025-11-24 00:41:40',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,'inactive',NULL,NULL,NULL,NULL,0,0,0,0,0);
CREATE TABLE user_sessions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  session_token TEXT UNIQUE NOT NULL,
  ip_address TEXT,
  user_agent TEXT,
  expires_at DATETIME NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
INSERT INTO "user_sessions" VALUES(1,11,'9e8b558a-f181-4819-a041-4b7bdb2ff8b2-micf8i1m',NULL,NULL,'2025-12-01T00:41:17.146Z','2025-11-24 00:41:17');
INSERT INTO "user_sessions" VALUES(2,11,'31d0eddc-0c5b-46f2-8825-ab34c9d46d70-micf907b',NULL,NULL,'2025-12-01T00:41:40.679Z','2025-11-24 00:41:40');
CREATE TABLE user_roles (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  role TEXT NOT NULL, 
  is_active INTEGER DEFAULT 1,
  granted_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  granted_by INTEGER,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
INSERT INTO "user_roles" VALUES(1,11,'collector',1,'2025-11-24 00:41:16',NULL);
CREATE TABLE artist_profiles (
  user_id INTEGER NOT NULL UNIQUE,
  art_style TEXT,
  major_medium TEXT,
  years_active INTEGER,
  education TEXT,
  notable_exhibitions TEXT,
  notable_awards TEXT,
  instagram_handle TEXT,
  twitter_handle TEXT,
  total_artworks INTEGER DEFAULT 0,
  total_sales INTEGER DEFAULT 0,
  avg_artwork_price INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE expert_profiles (
  user_id INTEGER NOT NULL UNIQUE,
  expert_type TEXT NOT NULL, 
  authority_level INTEGER DEFAULT 3, 
  specialization TEXT,
  institution TEXT,
  position TEXT,
  years_experience INTEGER,
  credentials TEXT,
  total_evaluations INTEGER DEFAULT 0,
  average_evaluation_score REAL DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE expert_applications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  expert_type TEXT NOT NULL,
  institution TEXT NOT NULL,
  position TEXT NOT NULL,
  years_experience INTEGER NOT NULL,
  specialization TEXT NOT NULL,
  resume_url TEXT,
  portfolio_url TEXT,
  credentials TEXT,
  motivation TEXT NOT NULL,
  expertise_description TEXT NOT NULL,
  application_status TEXT DEFAULT 'pending',
  admin_notes TEXT,
  rejection_reason TEXT,
  reviewed_by INTEGER,
  submitted_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  reviewed_at DATETIME,
  approved_at DATETIME,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE artwork_submissions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  category TEXT,
  technique TEXT,
  size_width INTEGER,
  size_height INTEGER,
  creation_year INTEGER,
  image_url TEXT NOT NULL,
  thumbnail_url TEXT,
  estimated_price INTEGER,
  currency TEXT DEFAULT 'KRW',
  exhibitions TEXT,
  awards TEXT,
  copyright_registration TEXT,
  blockchain_hash TEXT,
  license_type TEXT,
  submission_status TEXT DEFAULT 'pending',
  admin_notes TEXT,
  rejection_reason TEXT,
  submitted_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  reviewed_at DATETIME,
  approved_at DATETIME,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE user_expert_evaluations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  artwork_id INTEGER NOT NULL,
  expert_user_id INTEGER NOT NULL,
  expert_type TEXT NOT NULL,
  expert_authority_level INTEGER DEFAULT 3,
  artistic_value_score INTEGER DEFAULT 0,
  technical_skill_score INTEGER DEFAULT 0,
  originality_score INTEGER DEFAULT 0,
  market_potential_score INTEGER DEFAULT 0,
  collection_value_score INTEGER DEFAULT 0,
  overall_score INTEGER DEFAULT 0,
  recommended_price_min INTEGER,
  recommended_price_max INTEGER,
  evaluation_weight REAL DEFAULT 1.0,
  evaluation_status TEXT DEFAULT 'draft',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  submitted_at DATETIME,
  FOREIGN KEY (artwork_id) REFERENCES artworks(id) ON DELETE CASCADE,
  FOREIGN KEY (expert_user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE user_expert_comments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  evaluation_id INTEGER NOT NULL,
  artwork_id INTEGER NOT NULL,
  expert_user_id INTEGER NOT NULL,
  comment_type TEXT NOT NULL,
  comment_text TEXT NOT NULL,
  is_public INTEGER DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (evaluation_id) REFERENCES user_expert_evaluations(id) ON DELETE CASCADE,
  FOREIGN KEY (artwork_id) REFERENCES artworks(id) ON DELETE CASCADE,
  FOREIGN KEY (expert_user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE activity_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  action_type TEXT NOT NULL,
  entity_type TEXT,
  entity_id INTEGER,
  details TEXT,
  ip_address TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);
INSERT INTO "activity_logs" VALUES(1,11,'signup','user',NULL,'{"role":"collector","email":"test@gallerypia.com","is_organization":false,"organization_name":null}',NULL,'2025-11-24 00:41:16');
INSERT INTO "activity_logs" VALUES(2,11,'login','user',NULL,NULL,NULL,'2025-11-24 00:41:17');
INSERT INTO "activity_logs" VALUES(3,11,'login','user',NULL,NULL,NULL,'2025-11-24 00:41:40');
CREATE TABLE user_notifications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  notification_type TEXT NOT NULL,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  link_url TEXT,
  is_read INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE opensea_sync_jobs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  
  
  job_type TEXT NOT NULL, 
  contract_address TEXT,
  token_id TEXT,
  collection_slug TEXT,
  
  
  status TEXT DEFAULT 'pending', 
  progress INTEGER DEFAULT 0, 
  total_items INTEGER DEFAULT 0,
  processed_items INTEGER DEFAULT 0,
  failed_items INTEGER DEFAULT 0,
  
  
  imported_artworks TEXT, 
  error_log TEXT,
  
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  started_at DATETIME,
  completed_at DATETIME
);
CREATE TABLE opensea_artwork_mapping (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  artwork_id INTEGER NOT NULL UNIQUE,
  
  
  contract_address TEXT NOT NULL,
  token_id TEXT NOT NULL,
  collection_slug TEXT,
  opensea_url TEXT,
  
  
  last_synced_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  sync_status TEXT DEFAULT 'active', 
  
  
  opensea_metadata TEXT, 
  
  FOREIGN KEY (artwork_id) REFERENCES artworks(id) ON DELETE CASCADE
);
CREATE TABLE artist_verifications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  
  
  verification_type TEXT NOT NULL, 
  verification_status TEXT DEFAULT 'pending', 
  
  
  id_document_url TEXT,
  portfolio_urls TEXT, 
  credentials_urls TEXT, 
  
  
  verified_by INTEGER,
  verification_notes TEXT,
  rejection_reason TEXT,
  
  
  submitted_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  verified_at DATETIME,
  
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (verified_by) REFERENCES admin_users(id) ON DELETE SET NULL
);
CREATE TABLE system_settings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  setting_key TEXT UNIQUE NOT NULL,
  setting_value TEXT,
  setting_type TEXT DEFAULT 'string', 
  is_sensitive INTEGER DEFAULT 0, 
  description TEXT,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_by INTEGER,
  
  FOREIGN KEY (updated_by) REFERENCES admin_users(id) ON DELETE SET NULL
);
INSERT INTO "system_settings" VALUES(1,'opensea_api_key','','string',1,'OpenSea API Key','2025-11-17 06:09:03',NULL);
INSERT INTO "system_settings" VALUES(2,'opensea_api_enabled','0','boolean',0,'Enable OpenSea API integration','2025-11-17 06:09:03',NULL);
INSERT INTO "system_settings" VALUES(3,'expert_auto_approve','0','boolean',0,'Auto-approve expert applications','2025-11-17 06:09:03',NULL);
INSERT INTO "system_settings" VALUES(4,'artist_verification_required','1','boolean',0,'Require artist verification','2025-11-17 06:09:03',NULL);
INSERT INTO "system_settings" VALUES(5,'min_expert_experience_years','3','number',0,'Minimum years of experience for experts','2025-11-17 06:09:03',NULL);
CREATE TABLE user_kyc_verification (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL UNIQUE,
  
  
  legal_name TEXT NOT NULL,
  date_of_birth TEXT NOT NULL,
  nationality TEXT NOT NULL,
  id_type TEXT NOT NULL, 
  id_number TEXT NOT NULL,
  id_expiry_date TEXT,
  
  
  country TEXT NOT NULL,
  state_province TEXT,
  city TEXT NOT NULL,
  postal_code TEXT NOT NULL,
  street_address TEXT NOT NULL,
  
  
  phone_verified INTEGER DEFAULT 0,
  email_verified INTEGER DEFAULT 0,
  
  
  id_front_url TEXT,
  id_back_url TEXT,
  proof_of_address_url TEXT,
  selfie_url TEXT,
  
  
  risk_level TEXT DEFAULT 'pending', 
  aml_checked_at DATETIME,
  
  
  verification_status TEXT DEFAULT 'pending', 
  rejection_reason TEXT,
  verified_by INTEGER,
  verified_at DATETIME,
  
  
  submitted_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (verified_by) REFERENCES admin_users(id) ON DELETE SET NULL
);
CREATE TABLE artwork_extended_info (
  artwork_id INTEGER NOT NULL UNIQUE,
  
  
  exhibition_name TEXT,
  exhibition_start_date TEXT,
  exhibition_end_date TEXT,
  exhibition_venue TEXT,
  
  
  originality_description TEXT, 
  collection_value_description TEXT, 
  
  
  youtube_url TEXT,
  instagram_url TEXT,
  nft_platform_url TEXT,
  press_release_url TEXT,
  
  
  additional_images TEXT, 
  video_url TEXT,
  
  
  creation_technique TEXT,
  materials_used TEXT,
  dimensions_detailed TEXT, 
  
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (artwork_id) REFERENCES artworks(id) ON DELETE CASCADE
);
CREATE TABLE artwork_ownership (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  artwork_id INTEGER NOT NULL,
  owner_id INTEGER NOT NULL,
  
  
  quantity INTEGER DEFAULT 1, 
  percentage REAL DEFAULT 100.0, 
  
  
  acquired_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  acquired_from INTEGER, 
  acquisition_price INTEGER,
  acquisition_transaction_id INTEGER,
  
  
  is_current_owner INTEGER DEFAULT 1, 
  transferred_at DATETIME,
  
  FOREIGN KEY (artwork_id) REFERENCES artworks(id) ON DELETE CASCADE,
  FOREIGN KEY (acquisition_transaction_id) REFERENCES transactions(id) ON DELETE SET NULL
);
CREATE TABLE artwork_reviews (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  artwork_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  
  
  rating INTEGER NOT NULL, 
  title TEXT,
  review_text TEXT NOT NULL,
  
  
  artistic_value_rating INTEGER, 
  investment_potential_rating INTEGER, 
  authenticity_rating INTEGER, 
  
  
  helpful_count INTEGER DEFAULT 0,
  not_helpful_count INTEGER DEFAULT 0,
  
  
  is_verified_purchase INTEGER DEFAULT 0, 
  is_featured INTEGER DEFAULT 0,
  is_hidden INTEGER DEFAULT 0, 
  
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (artwork_id) REFERENCES artworks(id) ON DELETE CASCADE
);
CREATE TABLE review_votes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  review_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  vote_type TEXT NOT NULL, 
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (review_id) REFERENCES artwork_reviews(id) ON DELETE CASCADE,
  UNIQUE(review_id, user_id)
);
CREATE TABLE support_tickets (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  
  
  category TEXT NOT NULL, 
  subject TEXT NOT NULL,
  description TEXT NOT NULL,
  priority TEXT DEFAULT 'normal', 
  
  
  status TEXT DEFAULT 'open', 
  
  
  assigned_to INTEGER,
  
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  resolved_at DATETIME,
  closed_at DATETIME,
  
  FOREIGN KEY (assigned_to) REFERENCES admin_users(id) ON DELETE SET NULL
);
CREATE TABLE support_messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ticket_id INTEGER NOT NULL,
  sender_id INTEGER NOT NULL,
  sender_type TEXT NOT NULL, 
  
  message_text TEXT NOT NULL,
  attachment_url TEXT,
  
  is_internal_note INTEGER DEFAULT 0, 
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (ticket_id) REFERENCES support_tickets(id) ON DELETE CASCADE
);
CREATE TABLE user_favorites (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  artwork_id INTEGER NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (artwork_id) REFERENCES artworks(id) ON DELETE CASCADE,
  UNIQUE(user_id, artwork_id)
);
CREATE TABLE artwork_views (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  artwork_id INTEGER NOT NULL,
  user_id INTEGER, 
  ip_address TEXT,
  user_agent TEXT,
  viewed_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (artwork_id) REFERENCES artworks(id) ON DELETE CASCADE
);
CREATE TABLE auctions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  artwork_id INTEGER NOT NULL,
  seller_id INTEGER NOT NULL,
  starting_price REAL NOT NULL,
  current_price REAL,
  reserve_price REAL,
  currency TEXT DEFAULT 'ETH',
  start_time DATETIME DEFAULT CURRENT_TIMESTAMP,
  end_time DATETIME NOT NULL,
  status TEXT DEFAULT 'active',
  winner_id INTEGER,
  winning_bid_id INTEGER,
  total_bids INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE auction_bids (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  auction_id INTEGER NOT NULL,
  bidder_id INTEGER NOT NULL,
  bid_amount REAL NOT NULL,
  currency TEXT DEFAULT 'ETH',
  bid_time DATETIME DEFAULT CURRENT_TIMESTAMP,
  is_winning_bid INTEGER DEFAULT 0,
  status TEXT DEFAULT 'active'
);
CREATE TABLE purchase_offers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  artwork_id INTEGER NOT NULL,
  buyer_id INTEGER NOT NULL,
  seller_id INTEGER NOT NULL,
  offer_price REAL NOT NULL,
  currency TEXT DEFAULT 'ETH',
  message TEXT,
  status TEXT DEFAULT 'pending',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  responded_at DATETIME,
  expires_at DATETIME
);
CREATE TABLE exhibitions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  organizer_id INTEGER NOT NULL, 
  title TEXT NOT NULL,
  description TEXT,
  theme TEXT,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  location TEXT,
  venue_type TEXT DEFAULT 'physical', 
  max_artworks INTEGER DEFAULT 50,
  status TEXT DEFAULT 'planning', 
  visitor_count INTEGER DEFAULT 0,
  featured_image TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (organizer_id) REFERENCES users(id)
);
INSERT INTO "exhibitions" VALUES(1,1,'Digital Renaissance: NFT Art Exhibition','Explore the intersection of traditional art and blockchain technology','Contemporary Digital Art','2025-11-17','2026-02-15','Gallery Hall 1, MoMA','physical',50,'open',0,NULL,'2025-11-17 06:09:04','2025-11-17 06:09:04');
CREATE TABLE exhibition_artworks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  exhibition_id INTEGER NOT NULL,
  artwork_id INTEGER NOT NULL,
  display_order INTEGER DEFAULT 0,
  is_featured INTEGER DEFAULT 0,
  curator_notes TEXT,
  added_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (exhibition_id) REFERENCES exhibitions(id),
  FOREIGN KEY (artwork_id) REFERENCES artworks(id),
  UNIQUE(exhibition_id, artwork_id)
);
CREATE TABLE curation_requests (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  gallery_id INTEGER NOT NULL, 
  artwork_id INTEGER NOT NULL,
  artist_id INTEGER NOT NULL,
  request_message TEXT,
  offer_percentage REAL, 
  duration_months INTEGER, 
  status TEXT DEFAULT 'pending', 
  response_message TEXT,
  requested_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  responded_at DATETIME,
  FOREIGN KEY (gallery_id) REFERENCES users(id),
  FOREIGN KEY (artwork_id) REFERENCES artworks(id),
  FOREIGN KEY (artist_id) REFERENCES artists(id)
);
CREATE TABLE expert_rewards_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  expert_id INTEGER NOT NULL,
  evaluation_id INTEGER NOT NULL,
  artwork_id INTEGER NOT NULL,
  reward_eth REAL NOT NULL,
  tx_hash TEXT NOT NULL,
  status TEXT DEFAULT 'completed', 
  paid_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  notes TEXT,
  FOREIGN KEY (expert_id) REFERENCES users(id),
  FOREIGN KEY (evaluation_id) REFERENCES expert_evaluations(id),
  FOREIGN KEY (artwork_id) REFERENCES artworks(id)
);
CREATE TABLE artist_copyrights (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  artist_id INTEGER NOT NULL,
  artwork_title TEXT NOT NULL,
  registration_number TEXT NOT NULL, 
  registration_agency TEXT NOT NULL, 
  registration_date DATE NOT NULL,
  certificate_url TEXT NOT NULL, 
  country TEXT DEFAULT 'KR', 
  points REAL DEFAULT 30, 
  status TEXT DEFAULT 'pending',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  verified_at DATETIME,
  verified_by INTEGER,
  FOREIGN KEY (artist_id) REFERENCES users(id)
);
CREATE TABLE artist_curations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  artist_id INTEGER NOT NULL,
  curation_type TEXT NOT NULL, 
  exhibition_title TEXT NOT NULL,
  location TEXT NOT NULL,
  organizer TEXT NOT NULL,
  role TEXT NOT NULL, 
  start_date DATE NOT NULL,
  end_date DATE,
  is_director BOOLEAN DEFAULT 0, 
  proof_document_url TEXT,
  points REAL DEFAULT 0,
  status TEXT DEFAULT 'pending',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  verified_at DATETIME,
  verified_by INTEGER,
  FOREIGN KEY (artist_id) REFERENCES users(id)
);
CREATE TABLE artist_publications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  artist_id INTEGER NOT NULL,
  publication_type TEXT NOT NULL, 
  title TEXT NOT NULL,
  publisher TEXT,
  publication_date DATE NOT NULL,
  isbn_or_doi TEXT, 
  proof_url TEXT, 
  points REAL DEFAULT 0, 
  status TEXT DEFAULT 'pending',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  verified_at DATETIME,
  verified_by INTEGER,
  FOREIGN KEY (artist_id) REFERENCES users(id)
);
CREATE TABLE artist_ranks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  artist_id INTEGER NOT NULL UNIQUE,
  
  
  quantitative_exhibitions_score REAL DEFAULT 0, 
  quantitative_awards_score REAL DEFAULT 0, 
  quantitative_copyrights_score REAL DEFAULT 0, 
  quantitative_curations_score REAL DEFAULT 0, 
  quantitative_publications_score REAL DEFAULT 0, 
  quantitative_total_score REAL DEFAULT 0, 
  quantitative_weighted_score REAL DEFAULT 0, 
  
  
  qualitative_content_score REAL DEFAULT 0, 
  qualitative_expression_score REAL DEFAULT 0, 
  qualitative_originality_score REAL DEFAULT 0, 
  qualitative_collection_score REAL DEFAULT 0, 
  qualitative_sales_bonus REAL DEFAULT 0, 
  qualitative_total_score REAL DEFAULT 0, 
  qualitative_weighted_score REAL DEFAULT 0, 
  
  
  popularity_youtube_views INTEGER DEFAULT 0,
  popularity_youtube_score REAL DEFAULT 0,
  popularity_opensea_views INTEGER DEFAULT 0,
  popularity_opensea_score REAL DEFAULT 0,
  popularity_platform_views INTEGER DEFAULT 0,
  popularity_platform_score REAL DEFAULT 0,
  popularity_total_score REAL DEFAULT 0, 
  popularity_weighted_score REAL DEFAULT 0, 
  
  
  final_score REAL DEFAULT 0, 
  rank_tier TEXT DEFAULT 'G', 
  rank_grade TEXT DEFAULT 'B', 
  rank_category TEXT DEFAULT 'emerging', 
  
  
  last_calculated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  calculation_count INTEGER DEFAULT 0,
  
  FOREIGN KEY (artist_id) REFERENCES users(id)
);
CREATE TABLE artist_rank_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  artist_id INTEGER NOT NULL,
  previous_rank_tier TEXT,
  previous_rank_grade TEXT,
  previous_score REAL,
  new_rank_tier TEXT NOT NULL,
  new_rank_grade TEXT NOT NULL,
  new_score REAL NOT NULL,
  change_reason TEXT, 
  calculated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (artist_id) REFERENCES users(id)
);
CREATE TABLE artist_qualitative_evaluations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  artist_id INTEGER NOT NULL,
  artwork_id INTEGER, 
  evaluator_id INTEGER NOT NULL, 
  evaluator_rank TEXT NOT NULL, 
  
  
  content_concept_score REAL DEFAULT 0, 
  content_story_score REAL DEFAULT 0, 
  expression_communication_score REAL DEFAULT 0, 
  expression_technical_score REAL DEFAULT 0, 
  originality_uniqueness_score REAL DEFAULT 0, 
  originality_differentiation_score REAL DEFAULT 0, 
  collection_economic_value_score REAL DEFAULT 0, 
  collection_history_score REAL DEFAULT 0, 
  
  total_score REAL DEFAULT 0, 
  
  
  comments TEXT, 
  evaluation_date DATETIME DEFAULT CURRENT_TIMESTAMP,
  status TEXT DEFAULT 'completed', 
  
  FOREIGN KEY (artist_id) REFERENCES users(id),
  FOREIGN KEY (artwork_id) REFERENCES artworks(id),
  FOREIGN KEY (evaluator_id) REFERENCES users(id)
);
CREATE TABLE artwork_sales_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  artwork_id INTEGER NOT NULL,
  artist_id INTEGER NOT NULL,
  sale_platform TEXT NOT NULL, 
  sale_date DATE NOT NULL,
  sale_price REAL, 
  currency TEXT DEFAULT 'ETH',
  buyer_id INTEGER, 
  proof_url TEXT, 
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (artwork_id) REFERENCES artworks(id),
  FOREIGN KEY (artist_id) REFERENCES users(id),
  FOREIGN KEY (buyer_id) REFERENCES users(id)
);
CREATE TABLE password_reset_tokens (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  token TEXT NOT NULL UNIQUE,
  expires_at TEXT NOT NULL,
  used INTEGER DEFAULT 0,
  used_at TEXT,
  created_at TEXT NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE platform_settings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  setting_key TEXT UNIQUE NOT NULL,
  setting_value TEXT NOT NULL,
  setting_type TEXT NOT NULL DEFAULT 'string', 
  description TEXT,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_by INTEGER REFERENCES users(id)
);
INSERT INTO "platform_settings" VALUES(1,'platform_fee_percentage','2.5','number','플랫폼 수수료율 (%)','2025-11-17 06:09:05',NULL);
INSERT INTO "platform_settings" VALUES(2,'creator_royalty_percentage','10.0','number','크리에이터 로열티율 (%)','2025-11-17 06:09:05',NULL);
INSERT INTO "platform_settings" VALUES(3,'minimum_price_eth','0.001','number','최소 판매 가격 (ETH)','2025-11-17 06:09:05',NULL);
INSERT INTO "platform_settings" VALUES(4,'auction_min_increment_percentage','5.0','number','경매 최소 증가율 (%)','2025-11-17 06:09:05',NULL);
INSERT INTO "platform_settings" VALUES(5,'offer_expiry_days','7','number','오퍼 유효 기간 (일)','2025-11-17 06:09:05',NULL);
INSERT INTO "platform_settings" VALUES(6,'enable_offers','true','boolean','오퍼 기능 활성화','2025-11-17 06:09:05',NULL);
INSERT INTO "platform_settings" VALUES(7,'enable_auctions','true','boolean','경매 기능 활성화','2025-11-17 06:09:05',NULL);
INSERT INTO "platform_settings" VALUES(8,'gas_fee_coverage','buyer','string','가스비 부담 주체 (buyer/seller/split)','2025-11-17 06:09:05',NULL);
CREATE TABLE artwork_listings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  artwork_id INTEGER NOT NULL REFERENCES artworks(id) ON DELETE CASCADE,
  seller_id INTEGER NOT NULL REFERENCES users(id),
  listing_type TEXT NOT NULL DEFAULT 'fixed_price', 
  price_eth REAL, 
  currency TEXT DEFAULT 'ETH',
  
  
  auction_start_price_eth REAL,
  auction_reserve_price_eth REAL, 
  auction_end_time DATETIME,
  
  
  status TEXT NOT NULL DEFAULT 'active', 
  quantity INTEGER DEFAULT 1, 
  quantity_sold INTEGER DEFAULT 0,
  
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  sold_at DATETIME
);
CREATE TABLE nft_transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  artwork_id INTEGER NOT NULL REFERENCES artworks(id),
  listing_id INTEGER REFERENCES artwork_listings(id),
  
  
  seller_id INTEGER NOT NULL REFERENCES users(id),
  buyer_id INTEGER NOT NULL REFERENCES users(id),
  
  
  sale_price_eth REAL NOT NULL,
  platform_fee_eth REAL NOT NULL,
  creator_royalty_eth REAL,
  seller_receive_eth REAL NOT NULL, 
  
  
  transaction_type TEXT NOT NULL DEFAULT 'direct_sale', 
  
  
  transaction_hash TEXT,
  block_number INTEGER,
  gas_fee_eth REAL,
  
  
  status TEXT NOT NULL DEFAULT 'pending', 
  
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  confirmed_at DATETIME,
  
  
  metadata TEXT 
);
CREATE TABLE artwork_offers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  artwork_id INTEGER NOT NULL REFERENCES artworks(id) ON DELETE CASCADE,
  listing_id INTEGER REFERENCES artwork_listings(id),
  
  
  buyer_id INTEGER NOT NULL REFERENCES users(id),
  offer_price_eth REAL NOT NULL,
  currency TEXT DEFAULT 'ETH',
  
  
  expires_at DATETIME NOT NULL,
  
  
  status TEXT NOT NULL DEFAULT 'pending', 
  
  
  message TEXT,
  
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  responded_at DATETIME,
  
  
  response_message TEXT,
  responded_by INTEGER REFERENCES users(id)
);
CREATE TABLE auction_bids_enhanced (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  listing_id INTEGER REFERENCES artwork_listings(id),
  artwork_id INTEGER NOT NULL REFERENCES artworks(id),
  
  
  bidder_id INTEGER NOT NULL REFERENCES users(id),
  bid_amount_eth REAL NOT NULL,
  
  
  status TEXT NOT NULL DEFAULT 'active', 
  is_winning BOOLEAN DEFAULT 0,
  
  
  max_bid_eth REAL, 
  
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  
  
  transaction_hash TEXT
);
CREATE TABLE platform_revenue (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  transaction_id INTEGER NOT NULL REFERENCES nft_transactions(id),
  artwork_id INTEGER NOT NULL REFERENCES artworks(id),
  
  
  revenue_type TEXT NOT NULL, 
  amount_eth REAL NOT NULL,
  
  
  revenue_date DATE NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  
  
  description TEXT
);
CREATE TABLE creator_royalties (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  transaction_id INTEGER NOT NULL REFERENCES nft_transactions(id),
  artwork_id INTEGER NOT NULL REFERENCES artworks(id),
  
  
  creator_id INTEGER NOT NULL REFERENCES users(id),
  royalty_percentage REAL NOT NULL,
  royalty_amount_eth REAL NOT NULL,
  
  
  status TEXT NOT NULL DEFAULT 'pending', 
  paid_at DATETIME,
  
  
  payment_transaction_hash TEXT,
  
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE user_wallets (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  
  
  balance_eth REAL DEFAULT 0.0,
  locked_balance_eth REAL DEFAULT 0.0, 
  
  
  total_earned_eth REAL DEFAULT 0.0,
  total_spent_eth REAL DEFAULT 0.0,
  total_withdrawn_eth REAL DEFAULT 0.0,
  
  
  external_wallet_address TEXT,
  
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
INSERT INTO "user_wallets" VALUES(1,1,0,0,0,0,0,NULL,'2025-11-17 06:09:06','2025-11-17 06:09:06');
INSERT INTO "user_wallets" VALUES(2,2,0,0,0,0,0,NULL,'2025-11-17 06:09:06','2025-11-17 06:09:06');
CREATE TABLE wallet_transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  wallet_id INTEGER NOT NULL REFERENCES user_wallets(id),
  
  
  transaction_type TEXT NOT NULL, 
  amount_eth REAL NOT NULL,
  balance_after_eth REAL NOT NULL,
  
  
  related_transaction_id INTEGER REFERENCES nft_transactions(id),
  related_artwork_id INTEGER REFERENCES artworks(id),
  
  
  description TEXT,
  
  
  transaction_hash TEXT,
  
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE price_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  artwork_id INTEGER NOT NULL REFERENCES artworks(id) ON DELETE CASCADE,
  
  
  price_eth REAL NOT NULL,
  event_type TEXT NOT NULL, 
  
  
  transaction_id INTEGER REFERENCES nft_transactions(id),
  listing_id INTEGER REFERENCES artwork_listings(id),
  user_id INTEGER REFERENCES users(id),
  
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE trading_activity_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  
  
  activity_type TEXT NOT NULL, 
  user_id INTEGER REFERENCES users(id),
  artwork_id INTEGER REFERENCES artworks(id),
  
  
  details TEXT, 
  ip_address TEXT,
  user_agent TEXT,
  
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE daily_statistics (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  stat_date DATE UNIQUE NOT NULL,
  
  
  total_transactions INTEGER DEFAULT 0,
  total_volume_eth REAL DEFAULT 0.0,
  total_platform_fee_eth REAL DEFAULT 0.0,
  total_creator_royalty_eth REAL DEFAULT 0.0,
  
  
  total_listings INTEGER DEFAULT 0,
  new_listings INTEGER DEFAULT 0,
  sold_listings INTEGER DEFAULT 0,
  
  
  active_buyers INTEGER DEFAULT 0,
  active_sellers INTEGER DEFAULT 0,
  new_users INTEGER DEFAULT 0,
  
  
  avg_sale_price_eth REAL DEFAULT 0.0,
  min_sale_price_eth REAL,
  max_sale_price_eth REAL,
  
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE exchange_rates (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  currency TEXT NOT NULL, 
  eth_rate REAL NOT NULL, 
  
  
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
INSERT INTO "exchange_rates" VALUES(1,'USD',2000,'2025-11-17 06:09:06');
INSERT INTO "exchange_rates" VALUES(2,'KRW',2600000,'2025-11-17 06:09:06');
INSERT INTO "exchange_rates" VALUES(3,'EUR',1800,'2025-11-17 06:09:06');
CREATE TABLE nft_ownership_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  artwork_id INTEGER NOT NULL,
  
  
  contract_address TEXT NOT NULL,
  token_id TEXT NOT NULL,
  chain TEXT DEFAULT 'ethereum',
  
  
  from_address TEXT,
  to_address TEXT NOT NULL,
  
  
  transaction_hash TEXT,
  block_number INTEGER,
  block_timestamp INTEGER,
  
  
  transfer_type TEXT DEFAULT 'transfer', 
  
  
  price_eth REAL,
  price_usd REAL,
  price_krw INTEGER,
  
  
  marketplace TEXT, 
  marketplace_url TEXT,
  
  
  event_source TEXT DEFAULT 'manual', 
  
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  
  
  FOREIGN KEY (artwork_id) REFERENCES artworks(id) ON DELETE CASCADE
);
CREATE TABLE opensea_transaction_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  
  
  opensea_event_id TEXT UNIQUE,
  event_type TEXT NOT NULL, 
  
  
  contract_address TEXT NOT NULL,
  token_id TEXT NOT NULL,
  chain TEXT DEFAULT 'ethereum',
  artwork_id INTEGER, 
  
  
  transaction_hash TEXT,
  block_number INTEGER,
  block_timestamp INTEGER,
  
  
  seller_address TEXT,
  buyer_address TEXT,
  from_account TEXT,
  to_account TEXT,
  
  
  price_eth REAL,
  price_usd REAL,
  price_krw INTEGER,
  payment_token TEXT, 
  
  
  quantity INTEGER DEFAULT 1,
  
  
  collection_slug TEXT,
  collection_name TEXT,
  
  
  nft_name TEXT,
  nft_image_url TEXT,
  nft_permalink TEXT,
  
  
  marketplace_fee_eth REAL,
  creator_fee_eth REAL,
  
  
  auction_type TEXT, 
  duration INTEGER, 
  starting_price_eth REAL,
  ending_price_eth REAL,
  
  
  raw_event_data TEXT, 
  
  
  imported_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  last_synced_at DATETIME,
  
  
  FOREIGN KEY (artwork_id) REFERENCES artworks(id) ON DELETE SET NULL
);
CREATE TABLE nft_ownership_sync_status (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  artwork_id INTEGER NOT NULL UNIQUE,
  
  
  contract_address TEXT NOT NULL,
  token_id TEXT NOT NULL,
  chain TEXT DEFAULT 'ethereum',
  
  
  current_owner_address TEXT,
  current_owner_ens TEXT, 
  
  
  last_synced_at DATETIME,
  next_sync_at DATETIME,
  sync_status TEXT DEFAULT 'pending', 
  sync_error TEXT,
  
  
  total_transfers INTEGER DEFAULT 0,
  
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  
  
  FOREIGN KEY (artwork_id) REFERENCES artworks(id) ON DELETE CASCADE
);
CREATE TABLE opensea_import_jobs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  
  
  job_type TEXT NOT NULL, 
  job_status TEXT DEFAULT 'pending', 
  
  
  collection_slug TEXT,
  contract_address TEXT,
  token_id TEXT,
  chain TEXT DEFAULT 'ethereum',
  
  
  start_date INTEGER, 
  end_date INTEGER, 
  
  
  total_events INTEGER DEFAULT 0,
  processed_events INTEGER DEFAULT 0,
  failed_events INTEGER DEFAULT 0,
  
  
  imported_transactions INTEGER DEFAULT 0,
  imported_ownerships INTEGER DEFAULT 0,
  
  
  error_message TEXT,
  error_details TEXT, 
  
  
  started_at DATETIME,
  completed_at DATETIME,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  
  
  created_by_admin_id INTEGER,
  FOREIGN KEY (created_by_admin_id) REFERENCES admin_users(id) ON DELETE SET NULL
);
CREATE TABLE artwork_collections (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  artist_id INTEGER NOT NULL,
  collection_slug TEXT UNIQUE NOT NULL,  
  collection_name TEXT NOT NULL,  
  description TEXT,
  banner_image TEXT,  
  logo_image TEXT,  
  
  
  floor_price_eth REAL DEFAULT 0,  
  total_volume_eth REAL DEFAULT 0,  
  total_items INTEGER DEFAULT 0,  
  owners_count INTEGER DEFAULT 0,  
  
  
  royalty_percentage REAL DEFAULT 10.0,  
  is_featured BOOLEAN DEFAULT 0,  
  is_verified BOOLEAN DEFAULT 0,  
  
  
  category TEXT,  
  tags TEXT,  
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (artist_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE artwork_traits (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  artwork_id INTEGER NOT NULL,
  
  
  trait_type TEXT NOT NULL,  
  trait_value TEXT NOT NULL,  
  
  
  rarity_score REAL,  
  rarity_percentage REAL,  
  
  
  display_type TEXT,  
  max_value REAL,  
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (artwork_id) REFERENCES artworks(id) ON DELETE CASCADE
);
CREATE TABLE artwork_bundles (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  seller_id INTEGER NOT NULL,
  
  
  bundle_name TEXT NOT NULL,  
  description TEXT,
  bundle_slug TEXT UNIQUE,  
  
  
  total_price_eth REAL NOT NULL,  
  discount_percentage REAL DEFAULT 0,  
  original_price_eth REAL,  
  
  
  status TEXT DEFAULT 'active',  
  listing_type TEXT DEFAULT 'fixed_price',  
  
  
  auction_start_time DATETIME,
  auction_end_time DATETIME,
  highest_bid_eth REAL,
  highest_bidder_id INTEGER,
  
  
  sold_at DATETIME,
  buyer_id INTEGER,
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (seller_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (buyer_id) REFERENCES users(id) ON DELETE SET NULL,
  FOREIGN KEY (highest_bidder_id) REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE bundle_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  bundle_id INTEGER NOT NULL,
  artwork_id INTEGER NOT NULL,
  
  
  individual_price_eth REAL,  
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (bundle_id) REFERENCES artwork_bundles(id) ON DELETE CASCADE,
  FOREIGN KEY (artwork_id) REFERENCES artworks(id) ON DELETE CASCADE,
  
  UNIQUE(bundle_id, artwork_id)  
);
CREATE TABLE bundle_bids (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  bundle_id INTEGER NOT NULL,
  bidder_id INTEGER NOT NULL,
  
  bid_amount_eth REAL NOT NULL,
  is_winning BOOLEAN DEFAULT 0,  
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (bundle_id) REFERENCES artwork_bundles(id) ON DELETE CASCADE,
  FOREIGN KEY (bidder_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE lazy_mint_queue (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  artwork_id INTEGER NOT NULL,
  buyer_id INTEGER NOT NULL,
  
  
  contract_address TEXT,
  token_id TEXT,
  metadata_uri TEXT,  
  
  
  status TEXT DEFAULT 'pending',  
  error_message TEXT,
  
  
  transaction_hash TEXT,
  block_number INTEGER,
  gas_used REAL,
  
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  processed_at DATETIME,
  completed_at DATETIME,
  
  FOREIGN KEY (artwork_id) REFERENCES artworks(id) ON DELETE CASCADE,
  FOREIGN KEY (buyer_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE collection_daily_stats (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  collection_id INTEGER NOT NULL,
  stat_date DATE NOT NULL,
  
  
  daily_volume_eth REAL DEFAULT 0,
  daily_sales_count INTEGER DEFAULT 0,
  daily_unique_buyers INTEGER DEFAULT 0,
  
  
  floor_price_eth REAL,
  ceiling_price_eth REAL,
  average_price_eth REAL,
  
  
  total_owners INTEGER DEFAULT 0,
  new_owners_count INTEGER DEFAULT 0,
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (collection_id) REFERENCES artwork_collections(id) ON DELETE CASCADE,
  
  UNIQUE(collection_id, stat_date)
);
CREATE TABLE blockchain_networks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  
  
  chain_id INTEGER UNIQUE NOT NULL,
  chain_name TEXT NOT NULL,
  chain_slug TEXT UNIQUE NOT NULL,
  
  
  rpc_url TEXT NOT NULL,
  explorer_url TEXT,
  
  
  native_currency_symbol TEXT NOT NULL,
  native_currency_name TEXT,
  native_currency_decimals INTEGER DEFAULT 18,
  
  
  is_testnet BOOLEAN DEFAULT 0,
  is_active BOOLEAN DEFAULT 1,
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
INSERT INTO "blockchain_networks" VALUES(1,1,'Ethereum Mainnet','ethereum','https://eth.llamarpc.com','https://etherscan.io','ETH','Ether',18,0,1,'2025-11-17 06:09:06','2025-11-17 06:09:06');
INSERT INTO "blockchain_networks" VALUES(2,137,'Polygon','polygon','https://polygon-rpc.com','https://polygonscan.com','MATIC','Matic',18,0,1,'2025-11-17 06:09:06','2025-11-17 06:09:06');
INSERT INTO "blockchain_networks" VALUES(3,42161,'Arbitrum One','arbitrum','https://arb1.arbitrum.io/rpc','https://arbiscan.io','ETH','Ether',18,0,1,'2025-11-17 06:09:06','2025-11-17 06:09:06');
INSERT INTO "blockchain_networks" VALUES(4,10,'Optimism','optimism','https://mainnet.optimism.io','https://optimistic.etherscan.io','ETH','Ether',18,0,1,'2025-11-17 06:09:06','2025-11-17 06:09:06');
INSERT INTO "blockchain_networks" VALUES(5,8453,'Base','base','https://mainnet.base.org','https://basescan.org','ETH','Ether',18,0,1,'2025-11-17 06:09:06','2025-11-17 06:09:06');
CREATE TABLE activity_feed (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  
  
  activity_type TEXT NOT NULL,
  target_type TEXT NOT NULL,
  target_id INTEGER NOT NULL,
  
  
  actor_id INTEGER,
  
  
  metadata TEXT,
  
  
  is_public BOOLEAN DEFAULT 1,
  is_read BOOLEAN DEFAULT 0,
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (actor_id) REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE user_follows (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  follower_id INTEGER NOT NULL,
  following_id INTEGER NOT NULL,
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (follower_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (following_id) REFERENCES users(id) ON DELETE CASCADE,
  
  UNIQUE(follower_id, following_id)
);
CREATE TABLE collection_follows (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  collection_id INTEGER NOT NULL,
  
  
  notify_on_new_items BOOLEAN DEFAULT 1,
  notify_on_price_changes BOOLEAN DEFAULT 1,
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (collection_id) REFERENCES artwork_collections(id) ON DELETE CASCADE,
  
  UNIQUE(user_id, collection_id)
);
CREATE TABLE authenticity_verifications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  artwork_id INTEGER NOT NULL,
  
  
  verification_type TEXT NOT NULL CHECK(verification_type IN ('initial', 'resale', 'dispute', 'periodic')),
  status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending', 'processing', 'verified', 'suspicious', 'failed')),
  
  
  ai_confidence_score REAL DEFAULT 0, 
  ai_model_version TEXT DEFAULT 'v1.0',
  style_match_score REAL DEFAULT 0, 
  technical_analysis TEXT, 
  
  
  risk_level TEXT DEFAULT 'low' CHECK(risk_level IN ('low', 'medium', 'high', 'critical')),
  risk_factors TEXT, 
  
  
  image_hash TEXT, 
  image_fingerprint TEXT, 
  
  
  blockchain_verified BOOLEAN DEFAULT 0,
  metadata_verified BOOLEAN DEFAULT 0,
  artist_verified BOOLEAN DEFAULT 0,
  
  
  requires_expert_review BOOLEAN DEFAULT 0,
  expert_reviewer_id INTEGER,
  expert_notes TEXT,
  expert_decision TEXT CHECK(expert_decision IN ('approved', 'rejected', 'needs_info', NULL)),
  
  
  verification_started_at DATETIME,
  verification_completed_at DATETIME,
  processing_time_ms INTEGER,
  
  
  final_result TEXT CHECK(final_result IN ('authentic', 'likely_authentic', 'suspicious', 'likely_forgery', 'inconclusive', NULL)),
  recommendation TEXT, 
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (artwork_id) REFERENCES artworks(id) ON DELETE CASCADE,
  FOREIGN KEY (expert_reviewer_id) REFERENCES users(id)
);
CREATE TABLE artist_style_fingerprints (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  artist_id INTEGER NOT NULL,
  
  
  fingerprint_version TEXT DEFAULT 'v1.0',
  style_vector TEXT NOT NULL, 
  
  
  color_palette TEXT, 
  brushwork_pattern TEXT, 
  composition_style TEXT, 
  subject_preferences TEXT, 
  
  
  sample_artwork_ids TEXT, 
  sample_count INTEGER DEFAULT 0,
  confidence_level REAL DEFAULT 0, 
  
  
  consistency_score REAL DEFAULT 0, 
  uniqueness_score REAL DEFAULT 0, 
  
  
  trained_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  last_updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (artist_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE forgery_detections (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  
  
  suspected_artwork_id INTEGER NOT NULL,
  original_artwork_id INTEGER, 
  original_artist_id INTEGER,
  
  
  detection_method TEXT CHECK(detection_method IN ('ai_analysis', 'style_mismatch', 'user_report', 'expert_review', 'metadata_analysis')),
  similarity_score REAL DEFAULT 0, 
  
  
  evidence_type TEXT, 
  evidence_details TEXT, 
  comparison_images TEXT, 
  
  
  status TEXT DEFAULT 'reported' CHECK(status IN ('reported', 'investigating', 'confirmed', 'false_positive', 'resolved')),
  severity TEXT DEFAULT 'medium' CHECK(severity IN ('low', 'medium', 'high', 'critical')),
  
  
  action_taken TEXT, 
  resolution_notes TEXT,
  
  
  reported_by_user_id INTEGER,
  investigated_by_admin_id INTEGER,
  
  reported_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  resolved_at DATETIME,
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (suspected_artwork_id) REFERENCES artworks(id) ON DELETE CASCADE,
  FOREIGN KEY (original_artwork_id) REFERENCES artworks(id),
  FOREIGN KEY (original_artist_id) REFERENCES users(id),
  FOREIGN KEY (reported_by_user_id) REFERENCES users(id),
  FOREIGN KEY (investigated_by_admin_id) REFERENCES users(id)
);
CREATE TABLE verification_settings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  
  
  ai_model_name TEXT DEFAULT 'resnet50',
  ai_confidence_threshold REAL DEFAULT 70.0, 
  
  
  low_risk_threshold REAL DEFAULT 30.0,
  medium_risk_threshold REAL DEFAULT 60.0,
  high_risk_threshold REAL DEFAULT 85.0,
  
  
  style_match_threshold REAL DEFAULT 75.0, 
  
  
  auto_expert_review_threshold REAL DEFAULT 50.0, 
  high_value_threshold REAL DEFAULT 10.0, 
  
  
  require_blockchain_verification BOOLEAN DEFAULT 1,
  require_metadata_verification BOOLEAN DEFAULT 1,
  require_style_verification BOOLEAN DEFAULT 1,
  
  
  periodic_verification_enabled BOOLEAN DEFAULT 1,
  verification_interval_days INTEGER DEFAULT 365, 
  
  
  is_active BOOLEAN DEFAULT 1,
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
INSERT INTO "verification_settings" VALUES(1,'resnet50',70,30,60,85,75,50,10,1,1,1,1,365,1,'2025-11-17 06:09:07','2025-11-17 06:09:07');
CREATE TABLE verification_audit_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  verification_id INTEGER NOT NULL,
  
  
  event_type TEXT NOT NULL, 
  event_description TEXT,
  
  
  old_value TEXT, 
  new_value TEXT, 
  
  
  performed_by_user_id INTEGER,
  performed_by_system BOOLEAN DEFAULT 0,
  
  
  ip_address TEXT,
  user_agent TEXT,
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (verification_id) REFERENCES authenticity_verifications(id) ON DELETE CASCADE,
  FOREIGN KEY (performed_by_user_id) REFERENCES users(id)
);
CREATE TABLE royalty_configurations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  artwork_id INTEGER NOT NULL,
  
  
  config_version INTEGER DEFAULT 1, 
  is_active BOOLEAN DEFAULT 1,
  
  
  total_royalty_percentage REAL NOT NULL DEFAULT 10.0 CHECK(total_royalty_percentage >= 0 AND total_royalty_percentage <= 100),
  
  
  artist_split_percentage REAL NOT NULL DEFAULT 70.0 CHECK(artist_split_percentage >= 0 AND artist_split_percentage <= 100),
  gallery_split_percentage REAL DEFAULT 0 CHECK(gallery_split_percentage >= 0 AND gallery_split_percentage <= 100),
  curator_split_percentage REAL DEFAULT 0 CHECK(curator_split_percentage >= 0 AND curator_split_percentage <= 100),
  platform_split_percentage REAL DEFAULT 30.0 CHECK(platform_split_percentage >= 0 AND platform_split_percentage <= 100),
  
  
  artist_id INTEGER NOT NULL,
  gallery_id INTEGER, 
  curator_id INTEGER, 
  
  
  minimum_royalty_amount REAL DEFAULT 0, 
  apply_to_first_sale BOOLEAN DEFAULT 0, 
  perpetual BOOLEAN DEFAULT 1, 
  
  
  max_sales_count INTEGER, 
  
  
  expires_at DATETIME, 
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  created_by_user_id INTEGER,
  
  FOREIGN KEY (artwork_id) REFERENCES artworks(id) ON DELETE CASCADE,
  FOREIGN KEY (artist_id) REFERENCES users(id),
  FOREIGN KEY (gallery_id) REFERENCES galleries(id),
  FOREIGN KEY (curator_id) REFERENCES users(id),
  FOREIGN KEY (created_by_user_id) REFERENCES users(id)
);
CREATE TABLE sale_transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  artwork_id INTEGER NOT NULL,
  
  
  sale_number INTEGER NOT NULL DEFAULT 1, 
  sale_type TEXT NOT NULL CHECK(sale_type IN ('primary', 'secondary', 'auction', 'private')),
  
  
  seller_id INTEGER,
  buyer_id INTEGER NOT NULL,
  platform_transaction_id TEXT, 
  
  
  sale_price_eth REAL NOT NULL,
  sale_price_usd REAL, 
  currency TEXT DEFAULT 'ETH',
  
  
  platform_fee_percentage REAL DEFAULT 2.5,
  platform_fee_amount_eth REAL,
  
  
  royalty_config_id INTEGER,
  total_royalty_percentage REAL DEFAULT 0,
  total_royalty_amount_eth REAL DEFAULT 0,
  
  
  transaction_status TEXT DEFAULT 'pending' CHECK(transaction_status IN ('pending', 'completed', 'failed', 'refunded')),
  blockchain_tx_hash TEXT,
  blockchain_confirmed BOOLEAN DEFAULT 0,
  
  
  sale_date DATETIME DEFAULT CURRENT_TIMESTAMP,
  blockchain_confirmed_at DATETIME,
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (artwork_id) REFERENCES artworks(id) ON DELETE CASCADE,
  FOREIGN KEY (seller_id) REFERENCES users(id),
  FOREIGN KEY (buyer_id) REFERENCES users(id),
  FOREIGN KEY (royalty_config_id) REFERENCES royalty_configurations(id)
);
CREATE TABLE royalty_distributions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  sale_transaction_id INTEGER NOT NULL,
  royalty_config_id INTEGER NOT NULL,
  
  
  recipient_type TEXT NOT NULL CHECK(recipient_type IN ('artist', 'gallery', 'curator', 'platform', 'other')),
  recipient_id INTEGER, 
  
  
  split_percentage REAL NOT NULL,
  amount_eth REAL NOT NULL,
  amount_usd REAL,
  
  
  payment_status TEXT DEFAULT 'pending' CHECK(payment_status IN ('pending', 'processing', 'completed', 'failed', 'held')),
  payment_method TEXT, 
  
  
  blockchain_tx_hash TEXT,
  wallet_address TEXT,
  
  
  held_in_escrow BOOLEAN DEFAULT 0,
  escrow_reason TEXT,
  escrow_release_date DATETIME,
  
  
  processed_at DATETIME,
  failed_reason TEXT,
  retry_count INTEGER DEFAULT 0,
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (sale_transaction_id) REFERENCES sale_transactions(id) ON DELETE CASCADE,
  FOREIGN KEY (royalty_config_id) REFERENCES royalty_configurations(id)
);
CREATE TABLE royalty_earnings_summary (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  
  
  recipient_type TEXT NOT NULL CHECK(recipient_type IN ('artist', 'gallery', 'curator', 'platform')),
  recipient_id INTEGER NOT NULL,
  
  
  summary_period TEXT NOT NULL CHECK(summary_period IN ('daily', 'weekly', 'monthly', 'yearly', 'all_time')),
  period_start_date DATE,
  period_end_date DATE,
  
  
  total_earnings_eth REAL DEFAULT 0,
  total_earnings_usd REAL DEFAULT 0,
  
  
  total_transactions INTEGER DEFAULT 0,
  total_artworks INTEGER DEFAULT 0,
  
  
  pending_amount_eth REAL DEFAULT 0,
  completed_amount_eth REAL DEFAULT 0,
  failed_amount_eth REAL DEFAULT 0,
  
  
  last_calculated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  
  UNIQUE(recipient_type, recipient_id, summary_period, period_start_date)
);
CREATE TABLE royalty_payment_queue (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  distribution_id INTEGER NOT NULL,
  
  
  priority INTEGER DEFAULT 5 CHECK(priority >= 1 AND priority <= 10), 
  
  
  scheduled_for DATETIME DEFAULT CURRENT_TIMESTAMP,
  attempts INTEGER DEFAULT 0,
  max_attempts INTEGER DEFAULT 3,
  
  
  queue_status TEXT DEFAULT 'queued' CHECK(queue_status IN ('queued', 'processing', 'completed', 'failed', 'cancelled')),
  
  
  last_attempt_at DATETIME,
  last_error TEXT,
  
  
  locked_by TEXT, 
  locked_at DATETIME,
  lock_expires_at DATETIME,
  
  completed_at DATETIME,
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (distribution_id) REFERENCES royalty_distributions(id) ON DELETE CASCADE
);
CREATE TABLE royalty_disputes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  
  
  sale_transaction_id INTEGER,
  distribution_id INTEGER,
  
  
  dispute_type TEXT NOT NULL CHECK(dispute_type IN ('incorrect_amount', 'missing_payment', 'unauthorized_split', 'calculation_error', 'other')),
  dispute_reason TEXT NOT NULL,
  
  
  filed_by_user_id INTEGER NOT NULL,
  against_user_id INTEGER,
  
  
  evidence_documents TEXT, 
  expected_amount_eth REAL,
  actual_amount_eth REAL,
  
  
  status TEXT DEFAULT 'open' CHECK(status IN ('open', 'investigating', 'resolved', 'rejected', 'escalated')),
  resolution TEXT,
  
  
  assigned_to_admin_id INTEGER,
  resolved_by_admin_id INTEGER,
  
  
  filed_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  resolved_at DATETIME,
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (sale_transaction_id) REFERENCES sale_transactions(id),
  FOREIGN KEY (distribution_id) REFERENCES royalty_distributions(id),
  FOREIGN KEY (filed_by_user_id) REFERENCES users(id),
  FOREIGN KEY (against_user_id) REFERENCES users(id),
  FOREIGN KEY (assigned_to_admin_id) REFERENCES users(id),
  FOREIGN KEY (resolved_by_admin_id) REFERENCES users(id)
);
CREATE TABLE museum_partners (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  
  
  museum_name TEXT NOT NULL,
  museum_name_en TEXT, 
  museum_type TEXT CHECK(museum_type IN ('national', 'public', 'private', 'university', 'corporate', 'other')),
  
  
  official_website TEXT,
  contact_email TEXT NOT NULL,
  contact_phone TEXT,
  contact_person_name TEXT,
  contact_person_title TEXT,
  
  
  country TEXT DEFAULT 'KR',
  city TEXT,
  address TEXT,
  postal_code TEXT,
  
  
  establishment_year INTEGER,
  collection_size INTEGER, 
  annual_visitors INTEGER,
  museum_description TEXT,
  
  
  partnership_status TEXT DEFAULT 'pending' CHECK(partnership_status IN ('pending', 'approved', 'active', 'suspended', 'terminated')),
  partnership_tier TEXT CHECK(partnership_tier IN ('bronze', 'silver', 'gold', 'platinum')),
  
  
  partnership_start_date DATE,
  partnership_end_date DATE,
  revenue_share_percentage REAL DEFAULT 15.0, 
  
  
  platform_fee_percentage REAL DEFAULT 2.5,
  discount_on_platform_fee REAL DEFAULT 0, 
  
  
  verified BOOLEAN DEFAULT 0,
  verification_document_url TEXT, 
  tax_id TEXT, 
  
  
  admin_user_id INTEGER, 
  wallet_address TEXT, 
  
  
  logo_url TEXT,
  banner_url TEXT,
  brand_color TEXT, 
  
  
  total_nfts_issued INTEGER DEFAULT 0,
  total_revenue_eth REAL DEFAULT 0,
  total_exhibitions INTEGER DEFAULT 0,
  
  
  applied_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  reviewed_by_admin_id INTEGER,
  reviewed_at DATETIME,
  review_notes TEXT,
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP, partner_category TEXT DEFAULT 'museum' CHECK(partner_category IN ('museum', 'gallery', 'art_dealer')),
  
  FOREIGN KEY (admin_user_id) REFERENCES users(id),
  FOREIGN KEY (reviewed_by_admin_id) REFERENCES users(id)
);
INSERT INTO "museum_partners" VALUES(1,'소연갤러리',NULL,'private',NULL,'soyeon@soyeongallery.com',NULL,'이소연',NULL,'KR',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'approved','silver','2025-11-17',NULL,12,2.5,0,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,'2025-11-17 07:22:10',NULL,NULL,NULL,'2025-11-17 07:22:10','2025-11-17 07:22:10','gallery');
INSERT INTO "museum_partners" VALUES(2,'아트코리아',NULL,'private',NULL,'choi@artkorea.com',NULL,'최현준',NULL,'KR',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'approved','gold','2025-11-17',NULL,10,2.5,0,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,'2025-11-17 07:22:52',NULL,NULL,NULL,'2025-11-17 07:22:52','2025-11-17 07:22:52','art_dealer');
CREATE TABLE museum_nft_collections (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  museum_partner_id INTEGER NOT NULL,
  
  
  collection_name TEXT NOT NULL,
  collection_description TEXT,
  collection_type TEXT NOT NULL CHECK(collection_type IN ('artwork', 'exhibition_ticket', 'membership', 'commemorative', 'educational')),
  
  
  exhibition_id INTEGER, 
  
  
  total_supply INTEGER, 
  minted_count INTEGER DEFAULT 0,
  available_count INTEGER DEFAULT 0,
  
  
  price_eth REAL,
  price_usd REAL,
  is_free BOOLEAN DEFAULT 0,
  
  
  sale_type TEXT CHECK(sale_type IN ('fixed_price', 'auction', 'free_claim', 'whitelist_only')),
  sale_start_date DATETIME,
  sale_end_date DATETIME,
  
  
  benefits_description TEXT, 
  utility_type TEXT, 
  
  
  metadata_uri TEXT, 
  contract_address TEXT, 
  chain TEXT DEFAULT 'ethereum',
  
  
  royalty_percentage REAL DEFAULT 5.0,
  museum_royalty_split REAL DEFAULT 80.0, 
  
  
  status TEXT DEFAULT 'draft' CHECK(status IN ('draft', 'pending_approval', 'approved', 'active', 'sold_out', 'ended', 'cancelled')),
  
  
  approved_by_admin_id INTEGER,
  approved_at DATETIME,
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (museum_partner_id) REFERENCES museum_partners(id) ON DELETE CASCADE,
  FOREIGN KEY (exhibition_id) REFERENCES exhibitions(id),
  FOREIGN KEY (approved_by_admin_id) REFERENCES users(id)
);
CREATE TABLE museum_nft_holders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  collection_id INTEGER NOT NULL,
  
  
  token_id TEXT NOT NULL,
  nft_metadata TEXT, 
  
  
  current_owner_id INTEGER NOT NULL,
  original_owner_id INTEGER NOT NULL,
  
  
  purchased_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  purchase_price_eth REAL,
  purchase_transaction_hash TEXT,
  
  
  benefits_used TEXT, 
  benefits_usage_count INTEGER DEFAULT 0,
  
  
  is_active BOOLEAN DEFAULT 1,
  transferred_at DATETIME,
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (collection_id) REFERENCES museum_nft_collections(id) ON DELETE CASCADE,
  FOREIGN KEY (current_owner_id) REFERENCES users(id),
  FOREIGN KEY (original_owner_id) REFERENCES users(id)
);
CREATE TABLE museum_exhibition_collaborations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  museum_partner_id INTEGER NOT NULL,
  exhibition_id INTEGER NOT NULL,
  
  
  collaboration_type TEXT CHECK(collaboration_type IN ('co_curation', 'venue_rental', 'traveling_exhibition', 'digital_exhibition', 'joint_programming')),
  
  
  museum_role TEXT, 
  museum_contribution TEXT,
  
  
  revenue_split_percentage REAL, 
  fixed_fee_eth REAL, 
  
  
  collaboration_start_date DATE,
  collaboration_end_date DATE,
  
  
  agreement_document_url TEXT,
  signed_at DATETIME,
  
  
  total_visitors INTEGER DEFAULT 0,
  total_revenue_eth REAL DEFAULT 0,
  nfts_sold INTEGER DEFAULT 0,
  
  
  status TEXT DEFAULT 'proposed' CHECK(status IN ('proposed', 'negotiating', 'approved', 'active', 'completed', 'cancelled')),
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (museum_partner_id) REFERENCES museum_partners(id) ON DELETE CASCADE,
  FOREIGN KEY (exhibition_id) REFERENCES exhibitions(id) ON DELETE CASCADE
);
CREATE TABLE museum_membership_tiers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  museum_partner_id INTEGER NOT NULL,
  
  
  tier_name TEXT NOT NULL, 
  tier_level INTEGER DEFAULT 1, 
  
  
  price_eth REAL NOT NULL,
  price_usd REAL,
  duration_months INTEGER, 
  
  
  nft_collection_id INTEGER, 
  max_members INTEGER, 
  current_members INTEGER DEFAULT 0,
  
  
  benefits TEXT NOT NULL, 
  discount_percentage REAL DEFAULT 0, 
  
  
  free_exhibitions_count INTEGER, 
  priority_booking BOOLEAN DEFAULT 0,
  exclusive_events_access BOOLEAN DEFAULT 0,
  
  
  is_active BOOLEAN DEFAULT 1,
  available_from DATE,
  available_until DATE,
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (museum_partner_id) REFERENCES museum_partners(id) ON DELETE CASCADE,
  FOREIGN KEY (nft_collection_id) REFERENCES museum_nft_collections(id)
);
CREATE TABLE museum_revenue_records (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  museum_partner_id INTEGER NOT NULL,
  
  
  revenue_type TEXT NOT NULL CHECK(revenue_type IN ('nft_sale', 'ticket_sale', 'membership', 'royalty', 'rental_fee', 'other')),
  collection_id INTEGER, 
  exhibition_id INTEGER, 
  
  
  total_amount_eth REAL NOT NULL,
  total_amount_usd REAL,
  
  
  museum_share_percentage REAL NOT NULL,
  museum_share_eth REAL NOT NULL,
  platform_share_eth REAL NOT NULL,
  artist_share_eth REAL, 
  
  
  payment_status TEXT DEFAULT 'pending' CHECK(payment_status IN ('pending', 'processing', 'completed', 'failed')),
  payment_transaction_hash TEXT,
  paid_at DATETIME,
  
  
  reference_transaction_id INTEGER, 
  
  
  revenue_period_start DATE,
  revenue_period_end DATE,
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (museum_partner_id) REFERENCES museum_partners(id) ON DELETE CASCADE,
  FOREIGN KEY (collection_id) REFERENCES museum_nft_collections(id),
  FOREIGN KEY (exhibition_id) REFERENCES exhibitions(id)
);
CREATE TABLE museum_partnership_applications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  
  
  applicant_name TEXT NOT NULL,
  applicant_email TEXT NOT NULL,
  applicant_phone TEXT,
  applicant_title TEXT,
  
  
  museum_name TEXT NOT NULL,
  museum_website TEXT,
  museum_type TEXT,
  museum_country TEXT,
  museum_description TEXT,
  
  
  partnership_reason TEXT NOT NULL,
  expected_nft_program TEXT, 
  estimated_collection_size INTEGER,
  
  
  official_documents TEXT, 
  business_registration TEXT,
  authorization_letter TEXT, 
  
  
  application_status TEXT DEFAULT 'submitted' CHECK(application_status IN ('submitted', 'under_review', 'approved', 'rejected', 'additional_info_needed')),
  
  
  assigned_to_admin_id INTEGER,
  review_notes TEXT,
  rejection_reason TEXT,
  
  
  additional_info_requested TEXT,
  additional_info_provided TEXT,
  
  
  submitted_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  reviewed_at DATETIME,
  decision_at DATETIME,
  
  
  museum_partner_id INTEGER,
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP, partner_category TEXT DEFAULT 'museum' CHECK(partner_category IN ('museum', 'gallery', 'art_dealer')),
  
  FOREIGN KEY (assigned_to_admin_id) REFERENCES users(id),
  FOREIGN KEY (museum_partner_id) REFERENCES museum_partners(id)
);
INSERT INTO "museum_partnership_applications" VALUES(1,'김민수','museum@test.com',NULL,NULL,'국립현대미술관',NULL,'national','KR',NULL,'NFT 프로그램 시작','전시 티켓 NFT 발행',NULL,NULL,NULL,NULL,'submitted',NULL,NULL,NULL,NULL,NULL,'2025-11-17 06:14:02',NULL,NULL,NULL,'2025-11-17 06:14:02','2025-11-17 06:14:02','museum');
INSERT INTO "museum_partnership_applications" VALUES(2,'테스트','test@museum.kr',NULL,NULL,'국립현대미술관',NULL,'national','KR',NULL,'NFT 프로그램 시작',NULL,NULL,NULL,NULL,NULL,'submitted',NULL,NULL,NULL,NULL,NULL,'2025-11-17 06:46:10',NULL,NULL,NULL,'2025-11-17 06:46:10','2025-11-17 06:46:10','museum');
INSERT INTO "museum_partnership_applications" VALUES(3,'홍길동','test@gallery.com',NULL,NULL,'테스트 갤러리',NULL,'private','KR',NULL,'NFT 전시 프로그램 운영',NULL,NULL,NULL,NULL,NULL,'submitted',NULL,NULL,NULL,NULL,NULL,'2025-11-17 07:18:07',NULL,NULL,NULL,'2025-11-17 07:18:07','2025-11-17 07:18:07','gallery');
INSERT INTO "museum_partnership_applications" VALUES(4,'김현대','art@dealer.com',NULL,NULL,'김현대 아트딜러',NULL,'private','KR',NULL,'NFT 작품 중개 및 거래',NULL,NULL,NULL,NULL,NULL,'submitted',NULL,NULL,NULL,NULL,NULL,'2025-11-17 07:18:13',NULL,NULL,NULL,'2025-11-17 07:18:13','2025-11-17 07:18:13','art_dealer');
INSERT INTO "museum_partnership_applications" VALUES(5,'이소연','soyeon@soyeongallery.com',NULL,NULL,'소연갤러리',NULL,'private','KR',NULL,'삼청동에서 15년간 운영해온 갤러리입니다. 신진 작가 발굴과 NFT 전시 기획을 통해 디지털 아트 생태계 활성화에 기여하고 싶습니다. 월 2회 NFT 전시 개최 예정이며, 작가 50명 이상과 네트워크를 보유하고 있습니다.',NULL,NULL,NULL,NULL,NULL,'approved',NULL,NULL,NULL,NULL,NULL,'2025-11-17 07:20:56',NULL,'2025-11-17 07:22:10',1,'2025-11-17 07:20:56','2025-11-17 07:20:56','gallery');
INSERT INTO "museum_partnership_applications" VALUES(6,'최현준','choi@artkorea.com',NULL,NULL,'아트코리아',NULL,'private','KR',NULL,'10년 경력의 전문 아트딜러입니다. 국내외 200명 이상의 컬렉터 네트워크를 보유하고 있으며, 연간 50건 이상의 작품 거래 실적이 있습니다. NFT 시장 진출을 통해 신진 작가들의 해외 진출을 지원하고자 합니다.',NULL,NULL,NULL,NULL,NULL,'approved',NULL,NULL,NULL,NULL,NULL,'2025-11-17 07:22:47',NULL,'2025-11-17 07:22:52',2,'2025-11-17 07:22:47','2025-11-17 07:22:47','art_dealer');
CREATE TABLE museum_program_analytics (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  museum_partner_id INTEGER NOT NULL,
  
  
  analytics_period TEXT CHECK(analytics_period IN ('daily', 'weekly', 'monthly', 'quarterly', 'yearly')),
  period_start_date DATE NOT NULL,
  period_end_date DATE NOT NULL,
  
  
  nfts_minted INTEGER DEFAULT 0,
  nfts_sold INTEGER DEFAULT 0,
  nfts_transferred INTEGER DEFAULT 0,
  
  
  total_revenue_eth REAL DEFAULT 0,
  museum_revenue_eth REAL DEFAULT 0,
  platform_revenue_eth REAL DEFAULT 0,
  
  
  unique_visitors INTEGER DEFAULT 0,
  new_members INTEGER DEFAULT 0,
  active_members INTEGER DEFAULT 0,
  
  
  exhibitions_hosted INTEGER DEFAULT 0,
  total_exhibition_visitors INTEGER DEFAULT 0,
  
  
  social_media_reach INTEGER DEFAULT 0,
  press_mentions INTEGER DEFAULT 0,
  
  
  calculated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (museum_partner_id) REFERENCES museum_partners(id) ON DELETE CASCADE,
  UNIQUE(museum_partner_id, analytics_period, period_start_date)
);
DELETE FROM sqlite_sequence;
INSERT INTO "sqlite_sequence" VALUES('d1_migrations',24);
INSERT INTO "sqlite_sequence" VALUES('admin_users',1);
INSERT INTO "sqlite_sequence" VALUES('system_settings',5);
INSERT INTO "sqlite_sequence" VALUES('users',11);
INSERT INTO "sqlite_sequence" VALUES('exhibitions',1);
INSERT INTO "sqlite_sequence" VALUES('platform_settings',8);
INSERT INTO "sqlite_sequence" VALUES('exchange_rates',3);
INSERT INTO "sqlite_sequence" VALUES('user_wallets',2);
INSERT INTO "sqlite_sequence" VALUES('nft_ownership_sync_status',0);
INSERT INTO "sqlite_sequence" VALUES('artwork_collections',0);
INSERT INTO "sqlite_sequence" VALUES('artwork_traits',0);
INSERT INTO "sqlite_sequence" VALUES('blockchain_networks',5);
INSERT INTO "sqlite_sequence" VALUES('verification_settings',1);
INSERT INTO "sqlite_sequence" VALUES('museum_partnership_applications',6);
INSERT INTO "sqlite_sequence" VALUES('admin_sessions',1);
INSERT INTO "sqlite_sequence" VALUES('admin_activity_logs',1);
INSERT INTO "sqlite_sequence" VALUES('museum_partners',2);
INSERT INTO "sqlite_sequence" VALUES('user_roles',1);
INSERT INTO "sqlite_sequence" VALUES('activity_logs',3);
INSERT INTO "sqlite_sequence" VALUES('user_sessions',2);
CREATE INDEX idx_artworks_artist_id ON artworks(artist_id);
CREATE INDEX idx_artworks_category ON artworks(category);
CREATE INDEX idx_artworks_status ON artworks(status);
CREATE INDEX idx_artworks_is_minted ON artworks(is_minted);
CREATE INDEX idx_artworks_estimated_value ON artworks(estimated_value);
CREATE INDEX idx_artists_email ON artists(email);
CREATE INDEX idx_transactions_artwork_id ON transactions(artwork_id);
CREATE INDEX idx_valuation_history_artwork_id ON valuation_history(artwork_id);
CREATE INDEX idx_collection_artworks_collection_id ON collection_artworks(collection_id);
CREATE INDEX idx_collection_artworks_artwork_id ON collection_artworks(artwork_id);
CREATE INDEX idx_likes_artwork_id ON likes(artwork_id);
CREATE INDEX idx_expert_evaluations_artwork_id ON expert_evaluations(artwork_id);
CREATE INDEX idx_expert_evaluations_expert_level ON expert_evaluations(expert_level);
CREATE INDEX idx_admin_users_username ON admin_users(username);
CREATE INDEX idx_admin_users_email ON admin_users(email);
CREATE INDEX idx_admin_sessions_token ON admin_sessions(session_token);
CREATE INDEX idx_admin_sessions_user_id ON admin_sessions(admin_user_id);
CREATE INDEX idx_admin_sessions_expires_at ON admin_sessions(expires_at);
CREATE INDEX idx_admin_activity_logs_user_id ON admin_activity_logs(admin_user_id);
CREATE INDEX idx_admin_activity_logs_action ON admin_activity_logs(action);
CREATE INDEX idx_notifications_type ON notifications(type);
CREATE INDEX idx_notifications_is_read ON notifications(is_read);
CREATE INDEX idx_notifications_created_at ON notifications(created_at);
CREATE INDEX idx_artist_exhibitions_artist_id ON artist_exhibitions(artist_id);
CREATE INDEX idx_artist_exhibitions_year ON artist_exhibitions(exhibition_year);
CREATE INDEX idx_artist_awards_artist_id ON artist_awards(artist_id);
CREATE INDEX idx_artist_awards_year ON artist_awards(award_year);
CREATE INDEX idx_artwork_content_evaluation_artwork_id ON artwork_content_evaluation(artwork_id);
CREATE INDEX idx_artwork_certification_artwork_id ON artwork_certification(artwork_id);
CREATE INDEX idx_artwork_popularity_artwork_id ON artwork_popularity(artwork_id);
CREATE INDEX idx_artwork_final_valuation_artwork_id ON artwork_final_valuation(artwork_id);
CREATE INDEX idx_artwork_final_valuation_score ON artwork_final_valuation(final_value_score);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_username ON users(username);
CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_sessions_token ON user_sessions(session_token);
CREATE INDEX idx_sessions_user_id ON user_sessions(user_id);
CREATE UNIQUE INDEX idx_user_roles_unique ON user_roles(user_id, role);
CREATE INDEX idx_user_roles_user ON user_roles(user_id);
CREATE INDEX idx_expert_apps_user ON expert_applications(user_id);
CREATE INDEX idx_expert_apps_status ON expert_applications(application_status);
CREATE INDEX idx_submissions_user_id ON artwork_submissions(user_id);
CREATE INDEX idx_submissions_status ON artwork_submissions(submission_status);
CREATE INDEX idx_user_evaluations_artwork ON user_expert_evaluations(artwork_id);
CREATE INDEX idx_user_evaluations_expert ON user_expert_evaluations(expert_user_id);
CREATE INDEX idx_activity_user ON activity_logs(user_id);
CREATE INDEX idx_activity_type ON activity_logs(action_type);
CREATE INDEX idx_activity_created ON activity_logs(created_at);
CREATE INDEX idx_user_notifications_user ON user_notifications(user_id);
CREATE INDEX idx_user_notifications_read ON user_notifications(is_read);
CREATE INDEX idx_expert_apps_submitted ON expert_applications(submitted_at);
CREATE INDEX idx_opensea_jobs_status ON opensea_sync_jobs(status);
CREATE INDEX idx_opensea_jobs_created ON opensea_sync_jobs(created_at);
CREATE INDEX idx_opensea_mapping_artwork ON opensea_artwork_mapping(artwork_id);
CREATE INDEX idx_opensea_mapping_contract ON opensea_artwork_mapping(contract_address, token_id);
CREATE INDEX idx_user_roles_role ON user_roles(role);
CREATE INDEX idx_artist_verifications_user ON artist_verifications(user_id);
CREATE INDEX idx_artist_verifications_status ON artist_verifications(verification_status);
CREATE INDEX idx_system_settings_key ON system_settings(setting_key);
CREATE INDEX idx_kyc_user ON user_kyc_verification(user_id);
CREATE INDEX idx_kyc_status ON user_kyc_verification(verification_status);
CREATE INDEX idx_artwork_extended ON artwork_extended_info(artwork_id);
CREATE INDEX idx_transactions_artwork ON transactions(artwork_id);
CREATE INDEX idx_transactions_status ON transactions(status);
CREATE INDEX idx_transactions_type ON transactions(transaction_type);
CREATE INDEX idx_ownership_artwork ON artwork_ownership(artwork_id);
CREATE INDEX idx_ownership_owner ON artwork_ownership(owner_id);
CREATE INDEX idx_ownership_current ON artwork_ownership(is_current_owner);
CREATE INDEX idx_reviews_artwork ON artwork_reviews(artwork_id);
CREATE INDEX idx_reviews_user ON artwork_reviews(user_id);
CREATE INDEX idx_reviews_rating ON artwork_reviews(rating);
CREATE INDEX idx_review_votes_review ON review_votes(review_id);
CREATE INDEX idx_support_user ON support_tickets(user_id);
CREATE INDEX idx_support_status ON support_tickets(status);
CREATE INDEX idx_support_category ON support_tickets(category);
CREATE INDEX idx_support_messages_ticket ON support_messages(ticket_id);
CREATE INDEX idx_favorites_user ON user_favorites(user_id);
CREATE INDEX idx_favorites_artwork ON user_favorites(artwork_id);
CREATE INDEX idx_views_artwork ON artwork_views(artwork_id);
CREATE INDEX idx_views_date ON artwork_views(viewed_at);
CREATE INDEX idx_transactions_buyer ON transactions(buyer_id);
CREATE INDEX idx_transactions_seller ON transactions(seller_id);
CREATE INDEX idx_auctions_artwork ON auctions(artwork_id);
CREATE INDEX idx_auctions_status ON auctions(status);
CREATE INDEX idx_auction_bids_auction ON auction_bids(auction_id);
CREATE INDEX idx_auction_bids_bidder ON auction_bids(bidder_id);
CREATE INDEX idx_purchase_offers_artwork ON purchase_offers(artwork_id);
CREATE INDEX idx_purchase_offers_buyer ON purchase_offers(buyer_id);
CREATE INDEX idx_purchase_offers_seller ON purchase_offers(seller_id);
CREATE INDEX idx_exhibitions_organizer ON exhibitions(organizer_id);
CREATE INDEX idx_exhibitions_status ON exhibitions(status);
CREATE INDEX idx_exhibitions_dates ON exhibitions(start_date, end_date);
CREATE INDEX idx_exhibition_artworks_exhibition ON exhibition_artworks(exhibition_id);
CREATE INDEX idx_exhibition_artworks_artwork ON exhibition_artworks(artwork_id);
CREATE INDEX idx_curation_requests_gallery ON curation_requests(gallery_id);
CREATE INDEX idx_curation_requests_artwork ON curation_requests(artwork_id);
CREATE INDEX idx_curation_requests_status ON curation_requests(status);
CREATE INDEX idx_expert_rewards_expert ON expert_rewards_history(expert_id);
CREATE INDEX idx_expert_rewards_evaluation ON expert_rewards_history(evaluation_id);
CREATE INDEX idx_expert_evaluations_reward_status ON expert_evaluations(reward_status);
CREATE INDEX idx_artist_exhibitions_artist ON artist_exhibitions(artist_id);
CREATE INDEX idx_artist_exhibitions_type ON artist_exhibitions(exhibition_type);
CREATE INDEX idx_artist_awards_artist ON artist_awards(artist_id);
CREATE INDEX idx_artist_copyrights_artist ON artist_copyrights(artist_id);
CREATE INDEX idx_artist_curations_artist ON artist_curations(artist_id);
CREATE INDEX idx_artist_publications_artist ON artist_publications(artist_id);
CREATE INDEX idx_artist_ranks_score ON artist_ranks(final_score DESC);
CREATE INDEX idx_artist_ranks_tier ON artist_ranks(rank_tier);
CREATE INDEX idx_artist_rank_history_artist ON artist_rank_history(artist_id);
CREATE INDEX idx_qualitative_evaluations_artist ON artist_qualitative_evaluations(artist_id);
CREATE INDEX idx_qualitative_evaluations_evaluator ON artist_qualitative_evaluations(evaluator_id);
CREATE INDEX idx_sales_history_artist ON artwork_sales_history(artist_id);
CREATE INDEX idx_sales_history_artwork ON artwork_sales_history(artwork_id);
CREATE INDEX idx_password_reset_tokens_token ON password_reset_tokens(token);
CREATE INDEX idx_password_reset_tokens_user_id ON password_reset_tokens(user_id);
CREATE INDEX idx_password_reset_tokens_expires_at ON password_reset_tokens(expires_at);
CREATE UNIQUE INDEX idx_users_wallet_address ON users(wallet_address);
CREATE UNIQUE INDEX idx_users_google_id ON users(google_id);
CREATE INDEX idx_listings_artwork ON artwork_listings(artwork_id);
CREATE INDEX idx_listings_seller ON artwork_listings(seller_id);
CREATE INDEX idx_listings_status ON artwork_listings(status);
CREATE INDEX idx_listings_type ON artwork_listings(listing_type);
CREATE INDEX idx_transactions_created ON nft_transactions(created_at DESC);
CREATE INDEX idx_offers_artwork ON artwork_offers(artwork_id);
CREATE INDEX idx_offers_buyer ON artwork_offers(buyer_id);
CREATE INDEX idx_offers_status ON artwork_offers(status);
CREATE INDEX idx_offers_expires ON artwork_offers(expires_at);
CREATE INDEX idx_auction_bids_listing ON auction_bids_enhanced(listing_id);
CREATE INDEX idx_auction_bids_artwork ON auction_bids_enhanced(artwork_id);
CREATE INDEX idx_auction_bids_status ON auction_bids_enhanced(status);
CREATE INDEX idx_auction_bids_winning ON auction_bids_enhanced(is_winning);
CREATE INDEX idx_revenue_date ON platform_revenue(revenue_date DESC);
CREATE INDEX idx_revenue_type ON platform_revenue(revenue_type);
CREATE INDEX idx_revenue_transaction ON platform_revenue(transaction_id);
CREATE INDEX idx_royalties_creator ON creator_royalties(creator_id);
CREATE INDEX idx_royalties_status ON creator_royalties(status);
CREATE INDEX idx_royalties_transaction ON creator_royalties(transaction_id);
CREATE INDEX idx_wallet_user ON user_wallets(user_id);
CREATE INDEX idx_wallet_tx_user ON wallet_transactions(user_id);
CREATE INDEX idx_wallet_tx_type ON wallet_transactions(transaction_type);
CREATE INDEX idx_wallet_tx_created ON wallet_transactions(created_at DESC);
CREATE INDEX idx_price_history_artwork ON price_history(artwork_id);
CREATE INDEX idx_price_history_created ON price_history(created_at DESC);
CREATE INDEX idx_trading_activity_type ON trading_activity_logs(activity_type);
CREATE INDEX idx_trading_activity_user ON trading_activity_logs(user_id);
CREATE INDEX idx_trading_activity_artwork ON trading_activity_logs(artwork_id);
CREATE INDEX idx_trading_activity_created ON trading_activity_logs(created_at DESC);
CREATE INDEX idx_daily_stats_date ON daily_statistics(stat_date DESC);
CREATE INDEX idx_exchange_currency ON exchange_rates(currency);
CREATE INDEX idx_ownership_contract_token ON nft_ownership_history(contract_address, token_id);
CREATE INDEX idx_ownership_address ON nft_ownership_history(to_address);
CREATE INDEX idx_ownership_timestamp ON nft_ownership_history(block_timestamp);
CREATE INDEX idx_ownership_tx ON nft_ownership_history(transaction_hash);
CREATE INDEX idx_opensea_tx_contract_token ON opensea_transaction_history(contract_address, token_id);
CREATE INDEX idx_opensea_tx_event_type ON opensea_transaction_history(event_type);
CREATE INDEX idx_opensea_tx_timestamp ON opensea_transaction_history(block_timestamp);
CREATE INDEX idx_opensea_tx_artwork ON opensea_transaction_history(artwork_id);
CREATE INDEX idx_opensea_tx_collection ON opensea_transaction_history(collection_slug);
CREATE INDEX idx_opensea_tx_seller ON opensea_transaction_history(seller_address);
CREATE INDEX idx_opensea_tx_buyer ON opensea_transaction_history(buyer_address);
CREATE INDEX idx_sync_status_artwork ON nft_ownership_sync_status(artwork_id);
CREATE INDEX idx_sync_status_contract_token ON nft_ownership_sync_status(contract_address, token_id);
CREATE INDEX idx_sync_status_owner ON nft_ownership_sync_status(current_owner_address);
CREATE INDEX idx_import_jobs_status ON opensea_import_jobs(job_status);
CREATE INDEX idx_import_jobs_type ON opensea_import_jobs(job_type);
CREATE INDEX idx_import_jobs_collection ON opensea_import_jobs(collection_slug);
CREATE INDEX idx_collections_artist ON artwork_collections(artist_id);
CREATE INDEX idx_collections_slug ON artwork_collections(collection_slug);
CREATE INDEX idx_collections_featured ON artwork_collections(is_featured, floor_price_eth DESC);
CREATE INDEX idx_artworks_collection ON artworks(collection_id);
CREATE INDEX idx_traits_artwork ON artwork_traits(artwork_id);
CREATE INDEX idx_traits_type_value ON artwork_traits(trait_type, trait_value);
CREATE INDEX idx_traits_rarity ON artwork_traits(rarity_score DESC);
CREATE INDEX idx_bundles_seller ON artwork_bundles(seller_id);
CREATE INDEX idx_bundles_status ON artwork_bundles(status, created_at DESC);
CREATE INDEX idx_bundles_slug ON artwork_bundles(bundle_slug);
CREATE INDEX idx_bundle_items_bundle ON bundle_items(bundle_id);
CREATE INDEX idx_bundle_items_artwork ON bundle_items(artwork_id);
CREATE INDEX idx_bundle_bids_bundle ON bundle_bids(bundle_id, bid_amount_eth DESC);
CREATE INDEX idx_lazy_mint_status ON lazy_mint_queue(status, created_at);
CREATE INDEX idx_lazy_mint_artwork ON lazy_mint_queue(artwork_id);
CREATE INDEX idx_collection_stats_date ON collection_daily_stats(collection_id, stat_date DESC);
CREATE INDEX idx_collection_stats_volume ON collection_daily_stats(daily_volume_eth DESC);
CREATE INDEX idx_artworks_chain ON artworks(chain_id);
CREATE INDEX idx_activity_feed ON activity_feed(user_id, created_at DESC);
CREATE INDEX idx_user_follows_follower ON user_follows(follower_id);
CREATE INDEX idx_user_follows_following ON user_follows(following_id);
CREATE INDEX idx_collection_follows ON collection_follows(user_id);
CREATE INDEX idx_auth_verifications_artwork ON authenticity_verifications(artwork_id);
CREATE INDEX idx_auth_verifications_status ON authenticity_verifications(status);
CREATE INDEX idx_auth_verifications_result ON authenticity_verifications(final_result);
CREATE INDEX idx_auth_verifications_risk ON authenticity_verifications(risk_level);
CREATE INDEX idx_style_fingerprints_artist ON artist_style_fingerprints(artist_id);
CREATE UNIQUE INDEX idx_style_fingerprints_artist_version ON artist_style_fingerprints(artist_id, fingerprint_version);
CREATE INDEX idx_forgery_detections_suspected ON forgery_detections(suspected_artwork_id);
CREATE INDEX idx_forgery_detections_original ON forgery_detections(original_artwork_id);
CREATE INDEX idx_forgery_detections_status ON forgery_detections(status);
CREATE INDEX idx_verification_audit_log_verification ON verification_audit_log(verification_id);
CREATE INDEX idx_verification_audit_log_event_type ON verification_audit_log(event_type);
CREATE INDEX idx_royalty_config_artwork ON royalty_configurations(artwork_id);
CREATE INDEX idx_royalty_config_active ON royalty_configurations(is_active);
CREATE UNIQUE INDEX idx_royalty_config_artwork_active ON royalty_configurations(artwork_id, is_active) 
  WHERE is_active = 1;
CREATE INDEX idx_sale_transactions_artwork ON sale_transactions(artwork_id);
CREATE INDEX idx_sale_transactions_seller ON sale_transactions(seller_id);
CREATE INDEX idx_sale_transactions_buyer ON sale_transactions(buyer_id);
CREATE INDEX idx_sale_transactions_status ON sale_transactions(transaction_status);
CREATE INDEX idx_sale_transactions_date ON sale_transactions(sale_date);
CREATE INDEX idx_sale_transactions_blockchain ON sale_transactions(blockchain_tx_hash);
CREATE INDEX idx_royalty_distributions_sale ON royalty_distributions(sale_transaction_id);
CREATE INDEX idx_royalty_distributions_recipient ON royalty_distributions(recipient_id);
CREATE INDEX idx_royalty_distributions_status ON royalty_distributions(payment_status);
CREATE INDEX idx_royalty_distributions_type ON royalty_distributions(recipient_type);
CREATE INDEX idx_royalty_summary_recipient ON royalty_earnings_summary(recipient_type, recipient_id);
CREATE INDEX idx_royalty_summary_period ON royalty_earnings_summary(summary_period);
CREATE INDEX idx_payment_queue_status ON royalty_payment_queue(queue_status);
CREATE INDEX idx_payment_queue_scheduled ON royalty_payment_queue(scheduled_for);
CREATE INDEX idx_payment_queue_priority ON royalty_payment_queue(priority DESC);
CREATE INDEX idx_royalty_disputes_status ON royalty_disputes(status);
CREATE INDEX idx_royalty_disputes_filed_by ON royalty_disputes(filed_by_user_id);
CREATE INDEX idx_museum_partners_status ON museum_partners(partnership_status);
CREATE INDEX idx_museum_partners_tier ON museum_partners(partnership_tier);
CREATE INDEX idx_museum_partners_country ON museum_partners(country);
CREATE UNIQUE INDEX idx_museum_partners_name ON museum_partners(museum_name);
CREATE INDEX idx_museum_collections_museum ON museum_nft_collections(museum_partner_id);
CREATE INDEX idx_museum_collections_type ON museum_nft_collections(collection_type);
CREATE INDEX idx_museum_collections_status ON museum_nft_collections(status);
CREATE INDEX idx_museum_collections_exhibition ON museum_nft_collections(exhibition_id);
CREATE INDEX idx_museum_holders_collection ON museum_nft_holders(collection_id);
CREATE INDEX idx_museum_holders_owner ON museum_nft_holders(current_owner_id);
CREATE INDEX idx_museum_holders_active ON museum_nft_holders(is_active);
CREATE UNIQUE INDEX idx_museum_holders_token ON museum_nft_holders(collection_id, token_id);
CREATE INDEX idx_museum_collab_museum ON museum_exhibition_collaborations(museum_partner_id);
CREATE INDEX idx_museum_collab_exhibition ON museum_exhibition_collaborations(exhibition_id);
CREATE INDEX idx_museum_collab_status ON museum_exhibition_collaborations(status);
CREATE INDEX idx_membership_tiers_museum ON museum_membership_tiers(museum_partner_id);
CREATE INDEX idx_membership_tiers_active ON museum_membership_tiers(is_active);
CREATE INDEX idx_museum_revenue_museum ON museum_revenue_records(museum_partner_id);
CREATE INDEX idx_museum_revenue_type ON museum_revenue_records(revenue_type);
CREATE INDEX idx_museum_revenue_status ON museum_revenue_records(payment_status);
CREATE INDEX idx_partnership_apps_status ON museum_partnership_applications(application_status);
CREATE INDEX idx_partnership_apps_submitted ON museum_partnership_applications(submitted_at);
CREATE INDEX idx_museum_analytics_museum ON museum_program_analytics(museum_partner_id);
CREATE INDEX idx_museum_analytics_period ON museum_program_analytics(analytics_period);
CREATE INDEX idx_partnership_applications_category ON museum_partnership_applications(partner_category);
CREATE INDEX idx_museum_partners_category ON museum_partners(partner_category);
CREATE TRIGGER tr_record_listing_price
AFTER INSERT ON artwork_listings
FOR EACH ROW
WHEN NEW.status = 'active'
BEGIN
  INSERT INTO price_history (artwork_id, price_eth, event_type, listing_id, user_id)
  VALUES (NEW.artwork_id, COALESCE(NEW.price_eth, NEW.auction_start_price_eth), 'listing', NEW.id, NEW.seller_id);
END;
CREATE TRIGGER tr_update_stats_on_sale
AFTER INSERT ON nft_transactions
FOR EACH ROW
WHEN NEW.status = 'confirmed'
BEGIN
  
  UPDATE artworks 
  SET 
    last_sale_price_eth = NEW.sale_price_eth,
    last_sale_date = NEW.confirmed_at,
    total_sales = COALESCE(total_sales, 0) + 1,
    total_volume_eth = COALESCE(total_volume_eth, 0.0) + NEW.sale_price_eth,
    is_listed = 0
  WHERE id = NEW.artwork_id AND EXISTS (SELECT 1 FROM artworks WHERE id = NEW.artwork_id);
  
  
  UPDATE users
  SET
    total_sales_count = total_sales_count + 1,
    total_sales_volume_eth = total_sales_volume_eth + NEW.seller_receive_eth
  WHERE id = NEW.seller_id;
  
  
  UPDATE users
  SET
    total_purchases_count = total_purchases_count + 1,
    total_purchases_volume_eth = total_purchases_volume_eth + NEW.sale_price_eth
  WHERE id = NEW.buyer_id;
  
  
  INSERT INTO price_history (artwork_id, price_eth, event_type, transaction_id, user_id)
  VALUES (NEW.artwork_id, NEW.sale_price_eth, 'sale', NEW.id, NEW.buyer_id);
END;
CREATE TRIGGER tr_update_wallet_on_sale
AFTER INSERT ON nft_transactions
FOR EACH ROW
WHEN NEW.status = 'confirmed'
BEGIN
  
  UPDATE user_wallets
  SET 
    balance_eth = balance_eth + NEW.seller_receive_eth,
    total_earned_eth = total_earned_eth + NEW.seller_receive_eth,
    updated_at = CURRENT_TIMESTAMP
  WHERE user_id = NEW.seller_id;
  
  
  UPDATE user_wallets
  SET 
    balance_eth = balance_eth - NEW.sale_price_eth,
    total_spent_eth = total_spent_eth + NEW.sale_price_eth,
    updated_at = CURRENT_TIMESTAMP
  WHERE user_id = NEW.buyer_id;
END;
CREATE TRIGGER trg_update_ownership_sync_after_insert
AFTER INSERT ON nft_ownership_history
BEGIN
  UPDATE nft_ownership_sync_status
  SET 
    current_owner_address = NEW.to_address,
    total_transfers = total_transfers + 1,
    updated_at = CURRENT_TIMESTAMP
  WHERE artwork_id = NEW.artwork_id;
  
  
  INSERT OR IGNORE INTO nft_ownership_sync_status 
    (artwork_id, contract_address, token_id, chain, current_owner_address, total_transfers)
  VALUES 
    (NEW.artwork_id, NEW.contract_address, NEW.token_id, NEW.chain, NEW.to_address, 1);
END;
CREATE TRIGGER trg_update_import_job_progress
AFTER INSERT ON opensea_transaction_history
BEGIN
  UPDATE opensea_import_jobs
  SET 
    processed_events = processed_events + 1,
    imported_transactions = imported_transactions + 1
  WHERE 
    job_status = 'running' AND
    (collection_slug = NEW.collection_slug OR 
     (contract_address = NEW.contract_address AND token_id = NEW.token_id));
END;
CREATE TRIGGER trg_collection_item_added
AFTER UPDATE OF collection_id ON artworks
WHEN NEW.collection_id IS NOT NULL
BEGIN
  UPDATE artwork_collections
  SET 
    total_items = (SELECT COUNT(*) FROM artworks WHERE collection_id = NEW.collection_id),
    updated_at = datetime('now')
  WHERE id = NEW.collection_id;
END;
CREATE TRIGGER trg_bundle_slug_generation
AFTER INSERT ON artwork_bundles
WHEN NEW.bundle_slug IS NULL
BEGIN
  UPDATE artwork_bundles
  SET bundle_slug = 'bundle-' || NEW.id || '-' || substr(lower(hex(randomblob(4))), 1, 8)
  WHERE id = NEW.id;
END;
CREATE TRIGGER trg_lazy_mint_completed
AFTER UPDATE OF status ON lazy_mint_queue
WHEN NEW.status = 'completed'
BEGIN
  UPDATE artworks
  SET 
    is_minted = 1,
    minted_at = datetime('now'),
    minting_transaction_hash = NEW.transaction_hash,
    updated_at = datetime('now')
  WHERE id = NEW.artwork_id;
END;
CREATE TRIGGER trg_trait_rarity_calculation
AFTER INSERT ON artwork_traits
BEGIN
  
  UPDATE artwork_traits
  SET 
    rarity_percentage = (
      SELECT 
        ROUND(COUNT(*) * 100.0 / (
          SELECT COUNT(*) 
          FROM artworks a2 
          WHERE a2.collection_id = a.collection_id
        ), 2)
      FROM artwork_traits t2
      JOIN artworks a2 ON t2.artwork_id = a2.id
      WHERE t2.trait_type = NEW.trait_type
        AND t2.trait_value = NEW.trait_value
        AND a2.collection_id = a.collection_id
    ),
    rarity_score = 100 - (
      SELECT 
        COUNT(*) * 100.0 / (
          SELECT COUNT(*) 
          FROM artworks a2 
          WHERE a2.collection_id = a.collection_id
        )
      FROM artwork_traits t2
      JOIN artworks a2 ON t2.artwork_id = a2.id
      WHERE t2.trait_type = NEW.trait_type
        AND t2.trait_value = NEW.trait_value
        AND a2.collection_id = a.collection_id
    )
  FROM artworks a
  WHERE artwork_traits.id = NEW.id
    AND artwork_traits.artwork_id = a.id;
END;
CREATE TRIGGER update_authenticity_verifications_timestamp 
AFTER UPDATE ON authenticity_verifications
BEGIN
  UPDATE authenticity_verifications SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
END;
CREATE TRIGGER update_style_fingerprints_timestamp 
AFTER UPDATE ON artist_style_fingerprints
BEGIN
  UPDATE artist_style_fingerprints SET last_updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
END;
CREATE TRIGGER update_forgery_detections_timestamp 
AFTER UPDATE ON forgery_detections
BEGIN
  UPDATE forgery_detections SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
END;
CREATE TRIGGER log_verification_status_change 
AFTER UPDATE OF status ON authenticity_verifications
WHEN OLD.status != NEW.status
BEGIN
  INSERT INTO verification_audit_log (
    verification_id, 
    event_type, 
    event_description, 
    old_value, 
    new_value,
    performed_by_system
  ) VALUES (
    NEW.id,
    'status_changed',
    'Verification status changed from ' || OLD.status || ' to ' || NEW.status,
    json_object('status', OLD.status),
    json_object('status', NEW.status),
    1
  );
END;
CREATE TRIGGER auto_calculate_sale_fields
AFTER INSERT ON sale_transactions
BEGIN
  UPDATE sale_transactions
  SET 
    sale_number = (
      SELECT COALESCE(MAX(sale_number), 0) + 1 
      FROM sale_transactions 
      WHERE artwork_id = NEW.artwork_id AND id != NEW.id
    ),
    platform_fee_amount_eth = CASE 
      WHEN NEW.platform_fee_amount_eth IS NULL 
      THEN (NEW.sale_price_eth * NEW.platform_fee_percentage / 100)
      ELSE NEW.platform_fee_amount_eth
    END
  WHERE id = NEW.id;
END;
CREATE TRIGGER update_earnings_summary
AFTER UPDATE OF payment_status ON royalty_distributions
WHEN NEW.payment_status = 'completed' AND OLD.payment_status != 'completed'
BEGIN
  INSERT INTO royalty_earnings_summary (
    recipient_type,
    recipient_id,
    summary_period,
    period_start_date,
    period_end_date,
    total_earnings_eth,
    total_transactions,
    completed_amount_eth
  )
  VALUES (
    NEW.recipient_type,
    NEW.recipient_id,
    'all_time',
    date('1970-01-01'),
    date('2099-12-31'),
    NEW.amount_eth,
    1,
    NEW.amount_eth
  )
  ON CONFLICT(recipient_type, recipient_id, summary_period, period_start_date) 
  DO UPDATE SET
    total_earnings_eth = total_earnings_eth + NEW.amount_eth,
    total_transactions = total_transactions + 1,
    completed_amount_eth = completed_amount_eth + NEW.amount_eth,
    last_calculated_at = CURRENT_TIMESTAMP;
END;
CREATE TRIGGER update_royalty_config_timestamp
AFTER UPDATE ON royalty_configurations
BEGIN
  UPDATE royalty_configurations SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
END;
CREATE TRIGGER update_sale_transaction_timestamp
AFTER UPDATE ON sale_transactions
BEGIN
  UPDATE sale_transactions SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
END;
CREATE TRIGGER update_distribution_timestamp
AFTER UPDATE ON royalty_distributions
BEGIN
  UPDATE royalty_distributions SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
END;
CREATE TRIGGER update_museum_nft_count
AFTER UPDATE OF minted_count ON museum_nft_collections
BEGIN
  UPDATE museum_partners
  SET total_nfts_issued = (
    SELECT SUM(minted_count)
    FROM museum_nft_collections
    WHERE museum_partner_id = NEW.museum_partner_id
  )
  WHERE id = NEW.museum_partner_id;
END;
CREATE TRIGGER update_museum_partner_timestamp
AFTER UPDATE ON museum_partners
BEGIN
  UPDATE museum_partners SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
END;
CREATE TRIGGER update_museum_collection_timestamp
AFTER UPDATE ON museum_nft_collections
BEGIN
  UPDATE museum_nft_collections SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
END;
CREATE TRIGGER update_museum_holder_timestamp
AFTER UPDATE ON museum_nft_holders
BEGIN
  UPDATE museum_nft_holders SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
END;
CREATE VIEW v_artwork_valuation_summary AS
SELECT 
  a.id AS artwork_id,
  a.title AS artwork_title,
  ar.name AS artist_name,
  ar.artist_achievement_score,
  afv.module1_artist_achievement,
  afv.module2_artwork_content,
  afv.module3_certification,
  afv.module4_expert_evaluation,
  afv.module5_popularity,
  afv.final_value_score,
  afv.recommended_price_avg,
  afv.art_value_index,
  afv.market_transparency_index,
  afv.calculated_at
FROM artworks a
LEFT JOIN artists ar ON a.artist_id = ar.id
LEFT JOIN artwork_final_valuation afv ON a.id = afv.artwork_id
WHERE a.status IN ('approved', 'minted', 'sold');
CREATE VIEW v_recent_transactions AS
SELECT 
  t.id,
  t.artwork_id,
  a.title AS artwork_title,
  a.image_url AS artwork_image,
  t.seller_id,
  s.username AS seller_username,
  t.buyer_id,
  b.username AS buyer_username,
  t.sale_price_eth,
  t.platform_fee_eth,
  t.creator_royalty_eth,
  t.transaction_type,
  t.status,
  t.created_at,
  t.confirmed_at
FROM nft_transactions t
JOIN artworks a ON t.artwork_id = a.id
JOIN users s ON t.seller_id = s.id
JOIN users b ON t.buyer_id = b.id
ORDER BY t.created_at DESC;
CREATE VIEW v_platform_revenue_summary AS
SELECT 
  DATE(revenue_date) AS date,
  revenue_type,
  SUM(amount_eth) AS total_amount_eth,
  COUNT(*) AS transaction_count
FROM platform_revenue
GROUP BY DATE(revenue_date), revenue_type;
CREATE VIEW v_trending_artworks AS
SELECT 
  a.id,
  a.title,
  a.image_url,
  a.artist_id,
  u.username AS artist_name,
  a.current_price_eth,
  a.total_sales,
  a.total_volume_eth,
  a.views,
  a.likes
FROM artworks a
JOIN users u ON a.artist_id = u.id
WHERE a.is_listed = 1
ORDER BY a.total_volume_eth DESC, a.total_sales DESC
LIMIT 100;
CREATE VIEW v_top_sellers AS
SELECT 
  u.id,
  u.username,
  u.full_name,
  u.profile_image,
  u.total_sales_count,
  u.total_sales_volume_eth,
  COUNT(DISTINCT l.id) AS active_listings
FROM users u
LEFT JOIN artwork_listings l ON u.id = l.seller_id AND l.status = 'active'
WHERE u.total_sales_count > 0
GROUP BY u.id
ORDER BY u.total_sales_volume_eth DESC
LIMIT 100;
CREATE VIEW v_current_nft_owners AS
SELECT 
  a.id as artwork_id,
  a.title as artwork_title,
  a.nft_contract_address as contract_address,
  a.nft_token_id as token_id,
  a.blockchain_network as chain,
  s.current_owner_address,
  s.current_owner_ens,
  s.total_transfers,
  s.last_synced_at,
  s.sync_status
FROM artworks a
LEFT JOIN nft_ownership_sync_status s ON a.id = s.artwork_id
WHERE a.is_minted = 1;
CREATE VIEW v_recent_ownership_changes AS
SELECT 
  oh.id,
  oh.artwork_id,
  a.title as artwork_title,
  oh.contract_address,
  oh.token_id,
  oh.from_address,
  oh.to_address,
  oh.transfer_type,
  oh.price_eth,
  oh.price_krw,
  oh.marketplace,
  oh.transaction_hash,
  oh.block_timestamp,
  oh.created_at
FROM nft_ownership_history oh
JOIN artworks a ON oh.artwork_id = a.id
ORDER BY oh.created_at DESC
LIMIT 100;
CREATE VIEW v_opensea_transaction_summary AS
SELECT 
  ot.id,
  ot.opensea_event_id,
  ot.event_type,
  ot.contract_address,
  ot.token_id,
  ot.artwork_id,
  a.title as artwork_title,
  ot.seller_address,
  ot.buyer_address,
  ot.price_eth,
  ot.price_usd,
  ot.price_krw,
  ot.collection_slug,
  ot.collection_name,
  ot.nft_name,
  ot.nft_permalink,
  ot.block_timestamp,
  ot.imported_at
FROM opensea_transaction_history ot
LEFT JOIN artworks a ON ot.artwork_id = a.id
ORDER BY ot.block_timestamp DESC;
CREATE VIEW v_collection_traits_stats AS
SELECT 
  a.collection_id,
  ac.collection_name,
  t.trait_type,
  t.trait_value,
  COUNT(*) as count,
  ROUND(COUNT(*) * 100.0 / ac.total_items, 2) as percentage
FROM artwork_traits t
JOIN artworks a ON t.artwork_id = a.id
JOIN artwork_collections ac ON a.collection_id = ac.id
WHERE a.collection_id IS NOT NULL
GROUP BY a.collection_id, t.trait_type, t.trait_value
ORDER BY a.collection_id, t.trait_type, count DESC;
CREATE VIEW v_active_bundles AS
SELECT 
  b.*,
  u.name as seller_name,
  u.avatar as seller_avatar,
  COUNT(DISTINCT bi.artwork_id) as items_count,
  GROUP_CONCAT(DISTINCT a.image_url) as preview_images,
  CASE 
    WHEN b.listing_type = 'auction' AND datetime('now') > b.auction_end_time THEN 'expired'
    ELSE b.status
  END as current_status
FROM artwork_bundles b
JOIN users u ON b.seller_id = u.id
LEFT JOIN bundle_items bi ON b.id = bi.bundle_id
LEFT JOIN artworks a ON bi.artwork_id = a.id
GROUP BY b.id
HAVING current_status = 'active';
CREATE VIEW v_trending_collections AS
SELECT 
  ac.*,
  u.name as artist_name,
  u.avatar as artist_avatar,
  COALESCE(SUM(cds.daily_volume_eth), 0) as week_volume,
  COALESCE(SUM(cds.daily_sales_count), 0) as week_sales,
  ROUND(COALESCE(AVG(cds.floor_price_eth), ac.floor_price_eth), 4) as avg_floor_price
FROM artwork_collections ac
JOIN users u ON ac.artist_id = u.id
LEFT JOIN collection_daily_stats cds ON ac.id = cds.collection_id 
  AND cds.stat_date >= date('now', '-7 days')
GROUP BY ac.id
ORDER BY week_volume DESC, week_sales DESC
LIMIT 50;
CREATE VIEW v_collection_details AS
SELECT 
  ac.*,
  u.name as artist_name,
  u.email as artist_email,
  u.avatar as artist_avatar,
  u.bio as artist_bio,
  COUNT(DISTINCT a.id) as actual_items_count,
  COUNT(DISTINCT a.owner_id) as actual_owners_count,
  MIN(CASE WHEN al.status = 'active' THEN al.price_eth END) as current_floor_price,
  MAX(CASE WHEN al.status = 'active' THEN al.price_eth END) as current_ceiling_price,
  COALESCE(SUM(nt.amount_eth), 0) as actual_total_volume
FROM artwork_collections ac
JOIN users u ON ac.artist_id = u.id
LEFT JOIN artworks a ON ac.id = a.collection_id
LEFT JOIN artwork_listings al ON a.id = al.artwork_id
LEFT JOIN nft_transactions nt ON a.id = nt.artwork_id
GROUP BY ac.id;
CREATE VIEW pending_verifications_view AS
SELECT 
  av.id,
  av.artwork_id,
  a.title as artwork_title,
  a.artist_id,
  u.username as artist_name,
  av.verification_type,
  av.status,
  av.risk_level,
  av.ai_confidence_score,
  av.requires_expert_review,
  av.created_at,
  ROUND((julianday('now') - julianday(av.created_at)) * 24, 2) as hours_pending
FROM authenticity_verifications av
JOIN artworks a ON av.artwork_id = a.id
JOIN users u ON a.artist_id = u.id
WHERE av.status IN ('pending', 'processing')
ORDER BY av.risk_level DESC, av.created_at ASC;
CREATE VIEW suspicious_artworks_view AS
SELECT 
  av.artwork_id,
  a.title,
  a.artist_id,
  u.username as artist_name,
  av.risk_level,
  av.ai_confidence_score,
  av.final_result,
  COUNT(DISTINCT fd.id) as forgery_reports_count,
  av.updated_at
FROM authenticity_verifications av
JOIN artworks a ON av.artwork_id = a.id
JOIN users u ON a.artist_id = u.id
LEFT JOIN forgery_detections fd ON fd.suspected_artwork_id = av.artwork_id
WHERE av.risk_level IN ('high', 'critical')
  OR av.final_result IN ('suspicious', 'likely_forgery')
GROUP BY av.artwork_id
ORDER BY av.risk_level DESC, av.updated_at DESC;
CREATE VIEW artist_verification_stats AS
SELECT 
  u.id as artist_id,
  u.username as artist_name,
  COUNT(DISTINCT av.id) as total_verifications,
  COUNT(DISTINCT CASE WHEN av.final_result = 'authentic' THEN av.id END) as authentic_count,
  COUNT(DISTINCT CASE WHEN av.final_result IN ('suspicious', 'likely_forgery') THEN av.id END) as suspicious_count,
  AVG(av.ai_confidence_score) as avg_confidence_score,
  MAX(asf.confidence_level) as style_fingerprint_confidence,
  MAX(asf.last_updated_at) as style_last_updated
FROM users u
JOIN artworks a ON a.artist_id = u.id
LEFT JOIN authenticity_verifications av ON av.artwork_id = a.id
LEFT JOIN artist_style_fingerprints asf ON asf.artist_id = u.id
WHERE u.role = 'artist'
GROUP BY u.id
ORDER BY total_verifications DESC;
CREATE VIEW artist_royalty_dashboard AS
SELECT 
  u.id as artist_id,
  u.username as artist_name,
  COUNT(DISTINCT st.id) as total_sales,
  COUNT(DISTINCT CASE WHEN st.sale_type = 'secondary' THEN st.id END) as secondary_sales,
  SUM(st.sale_price_eth) as total_sales_volume_eth,
  SUM(rd.amount_eth) as total_royalties_earned_eth,
  SUM(CASE WHEN rd.payment_status = 'completed' THEN rd.amount_eth ELSE 0 END) as paid_royalties_eth,
  SUM(CASE WHEN rd.payment_status = 'pending' THEN rd.amount_eth ELSE 0 END) as pending_royalties_eth,
  AVG(rc.artist_split_percentage) as avg_artist_split_pct,
  MAX(st.sale_date) as last_sale_date
FROM users u
LEFT JOIN artworks a ON a.artist_id = u.id
LEFT JOIN sale_transactions st ON st.artwork_id = a.id
LEFT JOIN royalty_distributions rd ON rd.sale_transaction_id = st.id AND rd.recipient_type = 'artist' AND rd.recipient_id = u.id
LEFT JOIN royalty_configurations rc ON rc.artwork_id = a.id AND rc.is_active = 1
WHERE u.role = 'artist'
GROUP BY u.id;
CREATE VIEW gallery_royalty_dashboard AS
SELECT 
  g.id as gallery_id,
  g.name as gallery_name,
  COUNT(DISTINCT st.id) as total_sales,
  SUM(st.sale_price_eth) as total_sales_volume_eth,
  SUM(rd.amount_eth) as total_royalties_earned_eth,
  SUM(CASE WHEN rd.payment_status = 'completed' THEN rd.amount_eth ELSE 0 END) as paid_royalties_eth,
  SUM(CASE WHEN rd.payment_status = 'pending' THEN rd.amount_eth ELSE 0 END) as pending_royalties_eth,
  COUNT(DISTINCT a.artist_id) as artists_represented,
  MAX(st.sale_date) as last_sale_date
FROM galleries g
LEFT JOIN royalty_configurations rc ON rc.gallery_id = g.id AND rc.is_active = 1
LEFT JOIN artworks a ON a.id = rc.artwork_id
LEFT JOIN sale_transactions st ON st.artwork_id = a.id
LEFT JOIN royalty_distributions rd ON rd.sale_transaction_id = st.id AND rd.recipient_type = 'gallery' AND rd.recipient_id = g.id
GROUP BY g.id;
CREATE VIEW pending_royalty_payments AS
SELECT 
  rd.id,
  rd.recipient_type,
  rd.recipient_id,
  CASE 
    WHEN rd.recipient_type = 'artist' THEN u.username
    WHEN rd.recipient_type = 'gallery' THEN g.name
    WHEN rd.recipient_type = 'curator' THEN u2.username
    ELSE 'Platform'
  END as recipient_name,
  rd.amount_eth,
  rd.payment_status,
  a.title as artwork_title,
  st.sale_date,
  rd.created_at,
  ROUND((julianday('now') - julianday(rd.created_at)) * 24, 2) as hours_pending
FROM royalty_distributions rd
JOIN sale_transactions st ON rd.sale_transaction_id = st.id
JOIN artworks a ON st.artwork_id = a.id
LEFT JOIN users u ON rd.recipient_type = 'artist' AND rd.recipient_id = u.id
LEFT JOIN galleries g ON rd.recipient_type = 'gallery' AND rd.recipient_id = g.id
LEFT JOIN users u2 ON rd.recipient_type = 'curator' AND rd.recipient_id = u2.id
WHERE rd.payment_status IN ('pending', 'processing')
ORDER BY rd.created_at ASC;
CREATE VIEW active_museum_partners_view AS
SELECT 
  mp.id,
  mp.museum_name,
  mp.museum_type,
  mp.country,
  mp.partnership_tier,
  mp.partnership_start_date,
  mp.total_nfts_issued,
  mp.total_revenue_eth,
  mp.total_exhibitions,
  COUNT(DISTINCT mnc.id) as active_collections,
  COUNT(DISTINCT mnh.id) as total_holders,
  u.username as admin_username,
  u.email as admin_email
FROM museum_partners mp
LEFT JOIN museum_nft_collections mnc ON mnc.museum_partner_id = mp.id AND mnc.status = 'active'
LEFT JOIN museum_nft_holders mnh ON mnh.collection_id = mnc.id AND mnh.is_active = 1
LEFT JOIN users u ON mp.admin_user_id = u.id
WHERE mp.partnership_status = 'active'
GROUP BY mp.id
ORDER BY mp.total_revenue_eth DESC;
CREATE VIEW museum_collection_performance AS
SELECT 
  mnc.id as collection_id,
  mnc.collection_name,
  mnc.collection_type,
  mp.museum_name,
  mnc.total_supply,
  mnc.minted_count,
  mnc.available_count,
  ROUND(mnc.minted_count * 100.0 / NULLIF(mnc.total_supply, 0), 2) as mint_percentage,
  COUNT(DISTINCT mnh.id) as unique_holders,
  mnc.price_eth,
  mnc.price_eth * mnc.minted_count as total_revenue_eth,
  mnc.status,
  mnc.sale_start_date,
  mnc.sale_end_date
FROM museum_nft_collections mnc
JOIN museum_partners mp ON mnc.museum_partner_id = mp.id
LEFT JOIN museum_nft_holders mnh ON mnh.collection_id = mnc.id
GROUP BY mnc.id
ORDER BY total_revenue_eth DESC;
CREATE VIEW museum_membership_overview AS
SELECT 
  mp.id as museum_id,
  mp.museum_name,
  mmt.tier_name,
  mmt.price_eth,
  mmt.duration_months,
  mmt.current_members,
  mmt.max_members,
  CASE 
    WHEN mmt.max_members IS NOT NULL 
    THEN ROUND(mmt.current_members * 100.0 / mmt.max_members, 2)
    ELSE NULL
  END as capacity_percentage,
  mmt.is_active
FROM museum_partners mp
JOIN museum_membership_tiers mmt ON mmt.museum_partner_id = mp.id
WHERE mp.partnership_status = 'active'
ORDER BY mp.museum_name, mmt.tier_level;
CREATE VIEW partners_by_category AS
SELECT 
    partner_category,
    COUNT(*) as partner_count,
    COUNT(CASE WHEN partnership_status = 'active' THEN 1 END) as active_count,
    COUNT(CASE WHEN partnership_status = 'pending' THEN 1 END) as pending_count,
    COUNT(CASE WHEN partnership_status = 'suspended' THEN 1 END) as suspended_count
FROM museum_partners
GROUP BY partner_category;
CREATE VIEW pending_partnership_applications AS
SELECT 
    id,
    applicant_name,
    applicant_email,
    museum_name,
    museum_type,
    partner_category,
    partnership_reason,
    application_status,
    submitted_at,
    reviewed_at,
    CAST((julianday('now') - julianday(submitted_at)) AS INTEGER) as days_pending
FROM museum_partnership_applications
WHERE application_status = 'submitted'
ORDER BY submitted_at DESC;